

CREATE TABLE `BrakeABS` (
    `BrakeABSID` INT(10) NOT NULL,
    `BrakeABSName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`BrakeABSID`)
);
CREATE TABLE `BrakeType` (
    `BrakeTypeID` INT(10) NOT NULL,
    `BrakeTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`BrakeTypeID`)
);
CREATE TABLE `BrakeSystem` (
    `BrakeSystemID` INT(10) NOT NULL,
    `BrakeSystemName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`BrakeSystemID`)
);

CREATE TABLE `Aspiration` (
    `AspirationID` INT(10) NOT NULL,
    `AspirationName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`AspirationID`)
);

CREATE TABLE `BedType` (
    `BedTypeID` INT(10) NOT NULL,
    `BedTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`BedTypeID`)
);


CREATE TABLE `BodyType` (
    `BodyTypeID` INT(10) NOT NULL,
    `BodyTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`BodyTypeID`)
);




CREATE TABLE `ElecControlled` (
    `ElecControlledID` INT(10) NOT NULL,
    `ElecControlled` NVARCHAR(10) NOT NULL,
    PRIMARY KEY (`ElecControlledID`)
);


CREATE TABLE `FuelDeliverySubType` (
    `FuelDeliverySubTypeID` INT(10) NOT NULL,
    `FuelDeliverySubTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`FuelDeliverySubTypeID`)
);
CREATE TABLE `FuelDeliveryType` (
    `FuelDeliveryTypeID` INT(10) NOT NULL,
    `FuelDeliveryTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`FuelDeliveryTypeID`)
);
CREATE TABLE `FuelSystemControlType` (
    `FuelSystemControlTypeID` INT(10) NOT NULL,
    `FuelSystemControlTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`FuelSystemControlTypeID`)
);

CREATE TABLE `FuelType` (
    `FuelTypeID` INT(10) NOT NULL,
    `FuelTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`FuelTypeID`)
);
CREATE TABLE `IgnitionSystemType` (
    `IgnitionSystemTypeID` INT(10) NOT NULL,
    `IgnitionSystemTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`IgnitionSystemTypeID`)
);


CREATE TABLE `Region` (
    `RegionID` INT(10) NOT NULL,
    `ParentID` INT(10) DEFAULT NULL,
    `RegionAbbr` NVARCHAR(3) DEFAULT NULL,
    `RegionName` NVARCHAR(250) DEFAULT NULL,
    PRIMARY KEY (`RegionID`)
    
);

CREATE TABLE `SpringType` (
    `SpringTypeID` INT(10) NOT NULL,
    `SpringTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`SpringTypeID`)
);


CREATE TABLE `SteeringType` (
    `SteeringTypeID` INT(10) NOT NULL,
    `SteeringTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`SteeringTypeID`)
);

CREATE TABLE `TransmissionControlType` (
    `TransmissionControlTypeID` INT(10) NOT NULL,
    `TransmissionControlTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`TransmissionControlTypeID`)
);


CREATE TABLE `TransmissionType` (
    `TransmissionTypeID` INT(10) NOT NULL,
    `TransmissionTypeName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`TransmissionTypeID`)
);



CREATE TABLE Version(
	VersionDate date NOT NULL
);



CREATE TABLE `SteeringSystem` (
    `SteeringSystemID` INT(10) NOT NULL,
    `SteeringSystemName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`SteeringSystemID`)
);



CREATE TABLE `VehicleTypeGroup` (
    `VehicleTypeGroupID` INT(10) NOT NULL,
    `VehicleTypeGroupName` NVARCHAR(250) NOT NULL,
    PRIMARY KEY (`VehicleTypeGroupID`)
);



CREATE TABLE `VehicleType` (
    `VehicleTypeID` INT(10) NOT NULL,
    `VehicleTypeName` NVARCHAR(250) NOT NULL,
	`VehicleTypeGroupID` INT(10) NULL,
    PRIMARY KEY (`VehicleTypeID`)
);


CREATE TABLE `ChangeAttributeStates`(
	`ChangeAttributeStateID` int NOT NULL ,
	`ChangeAttributeState` nvarchar(255) NOT NULL,
PRIMARY KEY(`ChangeAttributeStateID`)
);

CREATE TABLE `ChangeReasons`(
	`ChangeReasonID` int NOT NULL,
	`ChangeReason` nvarchar(255) NOT NULL,
    PRIMARY KEY (`ChangeReasonID`)
);

CREATE TABLE `ChangeTableNames`(
	`TableNameID` int NOT NULL,
	`TableName` nvarchar(255) NOT NULL,
	`TableDescription` nvarchar(1000) NULL,
    PRIMARY KEY (`TableNameID`)
);
CREATE TABLE `Changes`(
	`ChangeID` int NOT NULL AUTO_INCREMENT,
	`RequestID` int NOT NULL,
	`ChangeReasonID` int NOT NULL,
	`RevDate` datetime NULL,
    PRIMARY KEY(`ChangeID`)
);

CREATE TABLE `ChangeDetails`(
	`ChangeDetailID` int NOT NULL AUTO_INCREMENT,
	`ChangeID` int NOT NULL,
	`ChangeAttributeStateID` int NOT NULL,
	`TableNameID` int NOT NULL,
	`PrimaryKeyColumnName` nvarchar(255) NULL,
	`PrimaryKeyBefore` int NULL,
	`PrimaryKeyAfter` int NULL,
	`ColumnName` nvarchar(255) NULL,
	`ColumnValueBefore` nvarchar(1000) NULL,
	`ColumnValueAfter` nvarchar(1000) NULL,
    PRIMARY KEY (`ChangeDetailID`) 
    
);
  

  CREATE TABLE VCdbChanges(
	VersionDate datetime NULL,
	TableName nvarchar(30) NULL,
	ID int NULL,
	Action char(1) NULL
) ;



