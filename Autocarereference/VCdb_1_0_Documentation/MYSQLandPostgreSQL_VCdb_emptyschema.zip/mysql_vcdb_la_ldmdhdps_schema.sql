CREATE TABLE `Abbreviation`(
	`Abbreviation` varchar(3) NOT NULL,
	`Description` varchar(20) NOT NULL,
	`LongDescription` varchar(200) NOT NULL,
  PRIMARY KEY (`Abbreviation`)
 );

CREATE TABLE `Make` (
    `MakeID` INT(10) NOT NULL,
    `MakeName` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`MakeID`)
);

CREATE TABLE `VehicleTypeGroup` (
    `VehicleTypeGroupID` INT(10) NOT NULL,
    `VehicleTypeGroupName` VARCHAR(50) NOT NULL
);

CREATE TABLE `VehicleType` (
    `VehicleTypeID` INT(10) NOT NULL,
    `VehicleTypeName` VARCHAR(50) NOT NULL,
    `VehicleTypeGroupID` INT(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleTypeID`)
);

CREATE TABLE `Model` (
    `ModelID` INT(10) NOT NULL,
    `ModelName` VARCHAR(100) DEFAULT NULL,
    `VehicleTypeID` INT(10) NOT NULL,
    PRIMARY KEY (`ModelID`),
    KEY `IDX_Model_VehicleTypeID` (`VehicleTypeID`),
    CONSTRAINT `FK_VehicleType_Model` FOREIGN KEY (`VehicleTypeID`)
        REFERENCES `vehicletype` (`VehicleTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `vehicletypemodel_fk` FOREIGN KEY (`VehicleTypeID`)
        REFERENCES `vehicletype` (`VehicleTypeID`)
);

CREATE TABLE `SubModel` (
    `SubModelID` INT(10) NOT NULL,
    `SubModelName` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`SubmodelID`)
);

CREATE TABLE `Region` (
    `RegionID` INT(10) NOT NULL,
    `ParentID` INT(10) DEFAULT NULL,
    `RegionAbbr` VARCHAR(3) DEFAULT NULL,
    `RegionName` VARCHAR(30) DEFAULT NULL,
    PRIMARY KEY (`RegionID`),
    KEY `IDX_Region_ParentID` (`ParentID`),
    CONSTRAINT `FK_Region_Parent` FOREIGN KEY (`ParentID`)
        REFERENCES `region` (`RegionID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION
);

CREATE TABLE `Year` (
    `YearID` INT(10) NOT NULL,
    PRIMARY KEY (`YearID`)
);


CREATE TABLE `PublicationStage` (
    `PublicationStageID` INT(10) NOT NULL,
    `PublicationStageName` VARCHAR(100) NOT NULL,
    PRIMARY KEY (`PublicationStageID`)
);

CREATE TABLE `BaseVehicle` (
    `BaseVehicleID` INT(10) NOT NULL,
    `YearID` INT(10) NOT NULL,
    `MakeID` INT(10) NOT NULL,
    `ModelID` INT(10) NOT NULL,
    PRIMARY KEY (`BaseVehicleID`),
    KEY `IDX_BaseVehicle_MakeID` (`MakeID`),
    KEY `IDX_BaseVehicle_ModelID` (`ModelID`),
    KEY `IDX_BaseVehicle_YearID` (`YearID`),
    CONSTRAINT `FK_Make_BaseVehicle` FOREIGN KEY (`MakeID`)
        REFERENCES `make` (`MakeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_Model_BaseVehicle` FOREIGN KEY (`ModelID`)
        REFERENCES `model` (`ModelID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_Year_BaseVehicle` FOREIGN KEY (`YearID`)
        REFERENCES `year` (`YearID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `makebasevehicle_fk` FOREIGN KEY (`MakeID`)
        REFERENCES `make` (`MakeID`),
    CONSTRAINT `modelbasevehicle_fk` FOREIGN KEY (`ModelID`)
        REFERENCES `model` (`ModelID`),
    CONSTRAINT `yearbasevehicle_fk` FOREIGN KEY (`YearID`)
        REFERENCES `year` (`YearID`)
);


CREATE TABLE `Vehicle` (
    `VehicleID` INT(10) NOT NULL,
    `BaseVehicleID` INT(10) NOT NULL,
    `SubmodelID` INT(10) NOT NULL,
    `RegionID` INT(10) NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    `PublicationStageID` INT(10) NOT NULL DEFAULT '4',
    `PublicationStageSource` VARCHAR(100) NOT NULL,
    `PublicationStageDate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`VehicleID`),
    KEY `IDX_Vehicle_BaseVehicleID` (`BaseVehicleID`),
    KEY `IDX_Vehicle_PublicationStage` (`PublicationStageID`),
    KEY `IDX_Vehicle_RegionID` (`RegionID`),
    KEY `IDX_Vehicle_SubmodelID` (`SubmodelID`),
    CONSTRAINT `FK_BaseVehicle_Vehicle` FOREIGN KEY (`BaseVehicleID`)
        REFERENCES `basevehicle` (`BaseVehicleID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_PublicationStage_Vehicle` FOREIGN KEY (`PublicationStageID`)
        REFERENCES `publicationstage` (`PublicationStageID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_Region_Vehicle` FOREIGN KEY (`RegionID`)
        REFERENCES `region` (`RegionID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_SubModel_Vehicle` FOREIGN KEY (`SubmodelID`)
        REFERENCES `submodel` (`SubmodelID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `basevehiclevehicle_fk` FOREIGN KEY (`BaseVehicleID`)
        REFERENCES `basevehicle` (`BaseVehicleID`),
    CONSTRAINT `publicationstage_fk` FOREIGN KEY (`PublicationStageID`)
        REFERENCES `publicationstage` (`PublicationStageID`),
    CONSTRAINT `regionvehicle_fk` FOREIGN KEY (`RegionID`)
        REFERENCES `region` (`RegionID`),
    CONSTRAINT `submodelvehicle_fk` FOREIGN KEY (`SubmodelID`)
        REFERENCES `submodel` (`SubmodelID`)
);

CREATE TABLE `BrakeABS` (
    `BrakeABSID` INT(10) NOT NULL,
    `BrakeABSName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`BrakeABSID`)
);
CREATE TABLE `BrakeType` (
    `BrakeTypeID` INT(10) NOT NULL,
    `BrakeTypeName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`BrakeTypeID`)
);
CREATE TABLE `BrakeSystem` (
    `BrakeSystemID` INT(10) NOT NULL,
    `BrakeSystemName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`BrakeSystemID`)
);
CREATE TABLE `BrakeConfig` (
    `BrakeConfigID` INT(10) NOT NULL,
    `FrontBrakeTypeID` INT(10) NOT NULL,
    `RearBrakeTypeID` INT(10) NOT NULL,
    `BrakeSystemID` INT(10) NOT NULL,
    `BrakeABSID` INT(10) NOT NULL,
    PRIMARY KEY (`BrakeConfigID`),
    KEY `IDX_BrakeConfig_BrakeABSID` (`BrakeABSID`),
    KEY `IDX_BrakeConfig_BrakeSystemID` (`BrakeSystemID`),
    KEY `IDX_BrakeConfig_FrontBrakeTypeID` (`FrontBrakeTypeID`),
    KEY `IDX_BrakeConfig_RearBrakeTypeID` (`RearBrakeTypeID`),
    CONSTRAINT `FK_BrakeABS_BrakeConfig` FOREIGN KEY (`BrakeABSID`)
        REFERENCES `brakeabs` (`BrakeABSID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_BrakeSystem_BrakeConfig` FOREIGN KEY (`BrakeSystemID`)
        REFERENCES `brakesystem` (`BrakeSystemID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_FrontBrakeType_BrakeConfig` FOREIGN KEY (`FrontBrakeTypeID`)
        REFERENCES `braketype` (`BrakeTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_RearBrakeType_BrakeConfig` FOREIGN KEY (`RearBrakeTypeID`)
        REFERENCES `braketype` (`BrakeTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `brakeabsbrakeconfig_fk` FOREIGN KEY (`BrakeABSID`)
        REFERENCES `brakeabs` (`BrakeABSID`),
    CONSTRAINT `brakesystembrakeconfig_fk` FOREIGN KEY (`BrakeSystemID`)
        REFERENCES `brakesystem` (`BrakeSystemID`),
    CONSTRAINT `braketypebrakeconfig1_fk` FOREIGN KEY (`RearBrakeTypeID`)
        REFERENCES `braketype` (`BrakeTypeID`),
    CONSTRAINT `braketypebrakeconfig_fk` FOREIGN KEY (`FrontBrakeTypeID`)
        REFERENCES `braketype` (`BrakeTypeID`)
);
CREATE TABLE `VehicleToBrakeConfig` (
    `VehicleToBrakeConfigID` INT(10) NOT NULL,
    `VehicleID` INT(10) NOT NULL,
    `BrakeConfigID` INT(10) NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleToBrakeConfigID`),
    KEY `IDX_VehicleToBrakeConfig_BrakeC` (`BrakeConfigID`),
    KEY `IDX_VehicleToBrakeConfig_Vehicl` (`VehicleID`),
    CONSTRAINT `brakeconfigvehicle_fk` FOREIGN KEY (`BrakeConfigID`)
        REFERENCES `brakeconfig` (`BrakeConfigID`),
    CONSTRAINT `vehicletobrakeconfigvehicle_fk` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`)
);


CREATE TABLE `Aspiration` (
    `AspirationID` INT(10) NOT NULL,
    `AspirationName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`AspirationID`)
);

CREATE TABLE `BedType` (
    `BedTypeID` INT(10) NOT NULL,
    `BedTypeName` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`BedTypeID`)
);
CREATE TABLE `BedLength` (
    `BedLengthID` INT(10) NOT NULL,
    `BedLength` VARCHAR(10) NOT NULL,
    `BedLengthMetric` VARCHAR(10) NOT NULL,
    PRIMARY KEY (`BedLengthID`)
);
CREATE TABLE `BedConfig` (
    `BedConfigID` INT(10) NOT NULL,
    `BedLengthID` INT(10) NOT NULL,
    `BedTypeID` INT(10) NOT NULL,
    PRIMARY KEY (`BedConfigID`),
    KEY `IDX_BedConfig_BedLengthID` (`BedLengthID`),
    KEY `IDX_BedConfig_BedTypeID` (`BedTypeID`),
    CONSTRAINT `FK_BedLength_BedConfig` FOREIGN KEY (`BedLengthID`)
        REFERENCES `bedlength` (`BedLengthID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_BedType_BedConfig` FOREIGN KEY (`BedTypeID`)
        REFERENCES `bedtype` (`BedTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `bedlengthbedconfig_fk` FOREIGN KEY (`BedLengthID`)
        REFERENCES `bedlength` (`BedLengthID`),
    CONSTRAINT `bedtypebedconfig_fk` FOREIGN KEY (`BedTypeID`)
        REFERENCES `bedtype` (`BedTypeID`)
);

CREATE TABLE `BodyType` (
    `BodyTypeID` INT(10) NOT NULL,
    `BodyTypeName` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`BodyTypeID`)
);
CREATE TABLE `BodyNumDoors` (
    `BodyNumDoorsID` INT(10) NOT NULL,
    `BodyNumDoors` VARCHAR(3) NOT NULL,
    PRIMARY KEY (`BodyNumDoorsID`)
);
CREATE TABLE `BodyStyleConfig` (
    `BodyStyleConfigID` INT(10) NOT NULL,
    `BodyNumDoorsID` INT(10) NOT NULL,
    `BodyTypeID` INT(10) NOT NULL,
    PRIMARY KEY (`BodyStyleConfigID`),
    KEY `IDX_BodyStyleConfig_BodyNumDoor` (`BodyNumDoorsID`),
    KEY `IDX_BodyStyleConfig_BodyTypeID` (`BodyTypeID`),
    CONSTRAINT `FK_BodyNumDoors_BodyStyleConfig` FOREIGN KEY (`BodyNumDoorsID`)
        REFERENCES `bodynumdoors` (`BodyNumDoorsID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_BodyType_BodyStyleConfig` FOREIGN KEY (`BodyTypeID`)
        REFERENCES `bodytype` (`BodyTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `bodynumdoorsbodystyleconfig_fk` FOREIGN KEY (`BodyNumDoorsID`)
        REFERENCES `bodynumdoors` (`BodyNumDoorsID`),
    CONSTRAINT `bodytypebodystyleconfig_fk` FOREIGN KEY (`BodyTypeID`)
        REFERENCES `bodytype` (`BodyTypeID`)
);

CREATE TABLE `Class` (
	`ClassID` int NOT NULL,
	`ClassName` varchar(30) NOT NULL,
 CONSTRAINT `PK_Class` PRIMARY KEY 
(
	`ClassID` ASC
) 
);

CREATE TABLE `CylinderHeadType` (
    `CylinderHeadTypeID` INT(10) NOT NULL,
    `CylinderHeadTypeName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`CylinderHeadTypeID`)
);
CREATE TABLE `DriveType` (
    `DriveTypeID` INT(10) NOT NULL,
    `DriveTypeName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`DriveTypeID`)
);
CREATE TABLE `ElecControlled` (
    `ElecControlledID` INT(10) NOT NULL,
    `ElecControlled` VARCHAR(3) NOT NULL,
    PRIMARY KEY (`ElecControlledID`)
);

CREATE TABLE `EngineBlock` (
    `EngineBlockID` INT(10) NOT NULL,
    `Liter` VARCHAR(6) NOT NULL,
    `CC` VARCHAR(8) NOT NULL,
    `CID` VARCHAR(7) NOT NULL,
    `Cylinders` VARCHAR(2) NOT NULL,
    `BlockType` VARCHAR(2) NOT NULL,
	    PRIMARY KEY (`EngineBlockID`),
    KEY `IDX_EngineBlock_BlockType` (`BlockType`),
    KEY `IDX_EngineBlock_CC` (`CC`),
    KEY `IDX_EngineBlock_CID` (`CID`),
    KEY `IDX_EngineBlock_Cylinders` (`Cylinders`),
	KEY `IDX_EngineBlock_Liter` (`Liter`)
	);		 

CREATE TABLE `EngineBoreStroke` (
    `EngineBoreStrokeID` INT(10) NOT NULL,
    `EngBoreIn` VARCHAR(10) NOT NULL,
    `EngBoreMetric` VARCHAR(10) NOT NULL,
    `EngStrokeIn` VARCHAR(10) NOT NULL,
    `EngStrokeMetric` VARCHAR(10) NOT NULL,
	    PRIMARY KEY (`EngineBoreStrokeID`),
    KEY `IDX_EngineBoreStroke_EngBoreIn` (`EngBoreIn`),
    KEY `IDX_EngineBoreStroke_EngBoreMetric` (`EngBoreMetric`),
    KEY `IDX_EngineBoreStroke_EngStrokeIn` (`EngStrokeIn`),
    KEY `IDX_EngineBoreStroke_EngStrokeMetric` (`EngStrokeMetric`)
	);
CREATE TABLE `EngineBase2` (
    `EngineBaseID` INT(10) NOT NULL,
    `EngineBlockID` INT(10) NOT NULL,
    `EngineBoreStrokeID` INT(10) NOT NULL,
        PRIMARY KEY (`EngineBaseID`),
    CONSTRAINT `EngineBaseEngineBlock_fk` FOREIGN KEY (`EngineBlockID`)
        REFERENCES `EngineBlock` (`EngineBlockID`),
	CONSTRAINT `EngineBaseEngineBoreStroke_fk` FOREIGN KEY (`EngineBoreStrokeID`)
        REFERENCES `EngineBoreStroke` (`EngineBoreStrokeID`)
);
CREATE TABLE `EngineBase` (
    `EngineBaseID` INT(10) NOT NULL,
    `Liter` VARCHAR(6) NOT NULL,
    `CC` VARCHAR(8) NOT NULL,
    `CID` VARCHAR(7) NOT NULL,
    `Cylinders` VARCHAR(2) NOT NULL,
    `BlockType` VARCHAR(2) NOT NULL,
    `EngBoreIn` VARCHAR(10) NOT NULL,
    `EngBoreMetric` VARCHAR(10) NOT NULL,
    `EngStrokeIn` VARCHAR(10) NOT NULL,
    `EngStrokeMetric` VARCHAR(10) NOT NULL,
    PRIMARY KEY (`EngineBaseID`),
    KEY `IDX_EngineBase_BlockType` (`BlockType`),
    KEY `IDX_EngineBase_CC` (`CC`),
    KEY `IDX_EngineBase_CID` (`CID`),
    KEY `IDX_EngineBase_Cylinders` (`Cylinders`),
    KEY `IDX_EngineBase_EngBoreIn` (`EngBoreIn`),
    KEY `IDX_EngineBase_EngBoreMetric` (`EngBoreMetric`),
    KEY `IDX_EngineBase_EngStrokeIn` (`EngStrokeIn`),
    KEY `IDX_EngineBase_EngStrokeMetric` (`EngStrokeMetric`),
    KEY `IDX_EngineBase_Liter` (`Liter`)
);
CREATE TABLE `EngineDesignation` (
    `EngineDesignationID` INT(10) NOT NULL,
    `EngineDesignationName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`EngineDesignationID`)
);
CREATE TABLE `EngineVersion` (
    `EngineVersionID` INT(10) NOT NULL,
    `EngineVersion` VARCHAR(20) NOT NULL,
    PRIMARY KEY (`EngineVersionID`)
);
CREATE TABLE `EngineVIN` (
    `EngineVINID` INT(10) NOT NULL,
    `EngineVINName` VARCHAR(5) NOT NULL,
    PRIMARY KEY (`EngineVINID`)
);
CREATE TABLE `FuelDeliverySubType` (
    `FuelDeliverySubTypeID` INT(10) NOT NULL,
    `FuelDeliverySubTypeName` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`FuelDeliverySubTypeID`)
);
CREATE TABLE `FuelDeliveryType` (
    `FuelDeliveryTypeID` INT(10) NOT NULL,
    `FuelDeliveryTypeName` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`FuelDeliveryTypeID`)
);
CREATE TABLE `FuelSystemControlType` (
    `FuelSystemControlTypeID` INT(10) NOT NULL,
    `FuelSystemControlTypeName` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`FuelSystemControlTypeID`)
);
CREATE TABLE `FuelSystemDesign` (
    `FuelSystemDesignID` INT(10) NOT NULL,
    `FuelSystemDesignName` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`FuelSystemDesignID`)
);
CREATE TABLE `FuelDeliveryConfig` (
    `FuelDeliveryConfigID` INT(10) NOT NULL,
    `FuelDeliveryTypeID` INT(10) NOT NULL,
    `FuelDeliverySubTypeID` INT(10) NOT NULL,
    `FuelSystemControlTypeID` INT(10) NOT NULL,
    `FuelSystemDesignID` INT(10) NOT NULL,
    PRIMARY KEY (`FuelDeliveryConfigID`),
    KEY `IDX_FuelDeliveryConfig_FuelDel1` (`FuelDeliverySubTypeID`),
    KEY `IDX_FuelDeliveryConfig_FuelDel2` (`FuelDeliveryTypeID`),
    KEY `IDX_FuelDeliveryConfig_FuelSys3` (`FuelSystemControlTypeID`),
    KEY `IDX_FuelDeliveryConfig_FuelSys4` (`FuelSystemDesignID`),
    CONSTRAINT `FK_FuelDeliverySubType_FuelDeliveryConfig` FOREIGN KEY (`FuelDeliverySubTypeID`)
        REFERENCES `fueldeliverysubtype` (`FuelDeliverySubTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_FuelDeliveryType_FuelDeliveryConfig` FOREIGN KEY (`FuelDeliveryTypeID`)
        REFERENCES `fueldeliverytype` (`FuelDeliveryTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_FuelSystemControlType_FuelDeliveryConfig` FOREIGN KEY (`FuelSystemControlTypeID`)
        REFERENCES `fuelsystemcontroltype` (`FuelSystemControlTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_FuelSystemDesign_FuelDeliveryConfig` FOREIGN KEY (`FuelSystemDesignID`)
        REFERENCES `fuelsystemdesign` (`FuelSystemDesignID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `fueldeliverysubtypefueldeliv_fk` FOREIGN KEY (`FuelDeliverySubTypeID`)
        REFERENCES `fueldeliverysubtype` (`FuelDeliverySubTypeID`),
    CONSTRAINT `fueldeliverytypefueldelivery_fk` FOREIGN KEY (`FuelDeliveryTypeID`)
        REFERENCES `fueldeliverytype` (`FuelDeliveryTypeID`),
    CONSTRAINT `fuelsystemcontroltypefueldel_fk` FOREIGN KEY (`FuelSystemControlTypeID`)
        REFERENCES `fuelsystemcontroltype` (`FuelSystemControlTypeID`),
    CONSTRAINT `fuelsystemdesignfueldelivery_fk` FOREIGN KEY (`FuelSystemDesignID`)
        REFERENCES `fuelsystemdesign` (`FuelSystemDesignID`)
);
CREATE TABLE `FuelType` (
    `FuelTypeID` INT(10) NOT NULL,
    `FuelTypeName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`FuelTypeID`)
);
CREATE TABLE `IgnitionSystemType` (
    `IgnitionSystemTypeID` INT(10) NOT NULL,
    `IgnitionSystemTypeName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`IgnitionSystemTypeID`)
);
CREATE TABLE `Mfr` (
    `MfrID` INT(10) NOT NULL,
    `MfrName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`MfrID`)
);
CREATE TABLE `MfrBodyCode` (
    `MfrBodyCodeID` INT(10) NOT NULL,
    `MfrBodyCodeName` VARCHAR(10) NOT NULL,
    PRIMARY KEY (`MfrBodyCodeID`)
);
CREATE TABLE `PowerOutput` (
    `PowerOutputID` INT(10) NOT NULL,
    `HorsePower` VARCHAR(10) NOT NULL,
    `KilowattPower` VARCHAR(10) NOT NULL
);
CREATE TABLE `Valves` (
    `ValvesID` INT(10) NOT NULL,
    `ValvesPerEngine` VARCHAR(3) NOT NULL,
    PRIMARY KEY (`ValvesID`)
);
CREATE TABLE `EngineConfig` (
    `EngineConfigID` INT(10) NOT NULL,
    `EngineDesignationID` INT(10) NOT NULL,
    `EngineVINID` INT(10) NOT NULL,
    `ValvesID` INT(10) NOT NULL,
    `EngineBaseID` INT(10) NOT NULL,
    `FuelDeliveryConfigID` INT(10) NOT NULL,
    `AspirationID` INT(10) NOT NULL,
    `CylinderHeadTypeID` INT(10) NOT NULL,
    `FuelTypeID` INT(10) NOT NULL,
    `IgnitionSystemTypeID` INT(10) NOT NULL,
    `EngineMfrID` INT(10) NOT NULL,
    `EngineVersionID` INT(10) NOT NULL,
    `PowerOutputID` INT(10) NOT NULL DEFAULT '1',
    PRIMARY KEY (`EngineConfigID`),
    KEY `IDX_EngineConfig_AspirationID` (`AspirationID`),
    KEY `IDX_EngineConfig_CylinderHeadTy` (`CylinderHeadTypeID`),
    KEY `IDX_EngineConfig_EngineBaseID` (`EngineBaseID`),
    KEY `IDX_EngineConfig_EngineDesignat` (`EngineDesignationID`),
    KEY `IDX_EngineConfig_EngineMfrID` (`EngineMfrID`),
    KEY `IDX_EngineConfig_EngineVersionID` (`EngineVersionID`),
    KEY `IDX_EngineConfig_EngineVINID` (`EngineVINID`),
    KEY `IDX_EngineConfig_FuelDeliveryCo` (`FuelDeliveryConfigID`),
    KEY `IDX_EngineConfig_FuelTypeID` (`FuelTypeID`),
    KEY `IDX_EngineConfig_IgnitionSystem` (`IgnitionSystemTypeID`),
    KEY `FK_EngineConfig_Valves1` (`ValvesID`),
    CONSTRAINT `FK_Aspiration_EngineConfig` FOREIGN KEY (`AspirationID`)
        REFERENCES `aspiration` (`AspirationID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_CylinderHeadType_EngineConfig` FOREIGN KEY (`CylinderHeadTypeID`)
        REFERENCES `cylinderheadtype` (`CylinderHeadTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineBase_EngineConfig` FOREIGN KEY (`EngineBaseID`)
        REFERENCES `enginebase` (`EngineBaseID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineConfig_Valves` FOREIGN KEY (`ValvesID`)
        REFERENCES `valves` (`ValvesID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineConfig_Valves1` FOREIGN KEY (`ValvesID`)
        REFERENCES `valves` (`ValvesID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineDesignation_EngineConfig` FOREIGN KEY (`EngineDesignationID`)
        REFERENCES `enginedesignation` (`EngineDesignationID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineVIN_EngineConfig` FOREIGN KEY (`EngineVINID`)
        REFERENCES `enginevin` (`EngineVINID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineVersion_EngineConfig` FOREIGN KEY (`EngineVersionID`)
        REFERENCES `engineversion` (`EngineVersionID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_FuelDeliveryConfig_EngineConfig` FOREIGN KEY (`FuelDeliveryConfigID`)
        REFERENCES `fueldeliveryconfig` (`FuelDeliveryConfigID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_FuelType_EngineConfig` FOREIGN KEY (`FuelTypeID`)
        REFERENCES `fueltype` (`FuelTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_IgnitionSystemType_EngineConfig` FOREIGN KEY (`IgnitionSystemTypeID`)
        REFERENCES `ignitionsystemtype` (`IgnitionSystemTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_Mfr_EngineConfig` FOREIGN KEY (`EngineMfrID`)
        REFERENCES `mfr` (`MfrID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `aspirationengineconfig_fk` FOREIGN KEY (`AspirationID`)
        REFERENCES `aspiration` (`AspirationID`),
    CONSTRAINT `cylinderheadtypeengineconfig_fk` FOREIGN KEY (`CylinderHeadTypeID`)
        REFERENCES `cylinderheadtype` (`CylinderHeadTypeID`),
    CONSTRAINT `enginebaseengineconfig_fk` FOREIGN KEY (`EngineBaseID`)
        REFERENCES `enginebase` (`EngineBaseID`),
    CONSTRAINT `enginedesignationengineconfi_fk` FOREIGN KEY (`EngineDesignationID`)
        REFERENCES `enginedesignation` (`EngineDesignationID`),
    CONSTRAINT `engineversionengineconfig_fk` FOREIGN KEY (`EngineVersionID`)
        REFERENCES `engineversion` (`EngineVersionID`),
    CONSTRAINT `enginevinengineconfig_fk` FOREIGN KEY (`EngineVINID`)
        REFERENCES `enginevin` (`EngineVINID`),
    CONSTRAINT `fueldeliveryconfigengineconf_fk` FOREIGN KEY (`FuelDeliveryConfigID`)
        REFERENCES `fueldeliveryconfig` (`FuelDeliveryConfigID`),
    CONSTRAINT `fueltypeengineconfig_fk` FOREIGN KEY (`FuelTypeID`)
        REFERENCES `fueltype` (`FuelTypeID`),
    CONSTRAINT `ignitionsystemtypeengineconf_fk` FOREIGN KEY (`IgnitionSystemTypeID`)
        REFERENCES `ignitionsystemtype` (`IgnitionSystemTypeID`),
    CONSTRAINT `mfrengineconfig_fk` FOREIGN KEY (`EngineMfrID`)
        REFERENCES `mfr` (`MfrID`)
);
CREATE TABLE `EngineConfig2` (
    `EngineConfigID` INT(10) NOT NULL,
    `EngineDesignationID` INT(10) NOT NULL,
    `EngineVINID` INT(10) NOT NULL,
    `ValvesID` INT(10) NOT NULL,
    `EngineBaseID` INT(10) NOT NULL,
	`EngineBlockID` INT(10) NOT NULL,
    `EngineBoreStrokeID` INT(10) NOT NULL,
    `FuelDeliveryConfigID` INT(10) NOT NULL,
    `AspirationID` INT(10) NOT NULL,
    `CylinderHeadTypeID` INT(10) NOT NULL,
    `FuelTypeID` INT(10) NOT NULL,
    `IgnitionSystemTypeID` INT(10) NOT NULL,
    `EngineMfrID` INT(10) NOT NULL,
    `EngineVersionID` INT(10) NOT NULL,
    `PowerOutputID` INT(10) NOT NULL DEFAULT '1',
    PRIMARY KEY (`EngineConfigID`),
    KEY `IDX_EngineConfig2_AspirationID` (`AspirationID`),
    KEY `IDX_EngineConfig2_CylinderHeadTy` (`CylinderHeadTypeID`),
    KEY `IDX_EngineConfig2_EngineBaseID` (`EngineBaseID`),
    KEY `IDX_EngineConfig2_EngineDesignat` (`EngineDesignationID`),
    KEY `IDX_EngineConfig2_EngineMfrID` (`EngineMfrID`),
    KEY `IDX_EngineConfig2_EngineVersionID` (`EngineVersionID`),
    KEY `IDX_EngineConfig2_EngineVINID` (`EngineVINID`),
    KEY `IDX_EngineConfig2_FuelDeliveryCo` (`FuelDeliveryConfigID`),
    KEY `IDX_EngineConfig2_FuelTypeID` (`FuelTypeID`),
    KEY `IDX_EngineConfig2_IgnitionSystem` (`IgnitionSystemTypeID`),
    KEY `FK_EngineConfig2_Valves1` (`ValvesID`),
    CONSTRAINT `FK_Aspiration_EngineConfig2` FOREIGN KEY (`AspirationID`)
        REFERENCES `aspiration` (`AspirationID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_CylinderHeadType_EngineConfig2` FOREIGN KEY (`CylinderHeadTypeID`)
        REFERENCES `cylinderheadtype` (`CylinderHeadTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineBase_EngineConfig2` FOREIGN KEY (`EngineBaseID`)
        REFERENCES `enginebase2` (`EngineBaseID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
		    CONSTRAINT `FK_EngineBlock_EngineConfig2` FOREIGN KEY (`EngineBlockID`)
        REFERENCES `EngineBlock` (`EngineBlockID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
		    CONSTRAINT `FK_EngineBoreStroke_EngineConfig2` FOREIGN KEY (`EngineBoreStrokeID`)
        REFERENCES `EngineBoreStroke` (`EngineBoreStrokeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineConfig2_Valves` FOREIGN KEY (`ValvesID`)
        REFERENCES `valves` (`ValvesID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineConfig2_Valves1` FOREIGN KEY (`ValvesID`)
        REFERENCES `valves` (`ValvesID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineDesignation_EngineConfig2` FOREIGN KEY (`EngineDesignationID`)
        REFERENCES `enginedesignation` (`EngineDesignationID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineVIN_EngineConfig2` FOREIGN KEY (`EngineVINID`)
        REFERENCES `enginevin` (`EngineVINID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_EngineVersion_EngineConfig2` FOREIGN KEY (`EngineVersionID`)
        REFERENCES `engineversion` (`EngineVersionID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_FuelDeliveryConfig_EngineConfig2` FOREIGN KEY (`FuelDeliveryConfigID`)
        REFERENCES `fueldeliveryconfig` (`FuelDeliveryConfigID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_FuelType_EngineConfig2` FOREIGN KEY (`FuelTypeID`)
        REFERENCES `fueltype` (`FuelTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_IgnitionSystemType_EngineConfig2` FOREIGN KEY (`IgnitionSystemTypeID`)
        REFERENCES `ignitionsystemtype` (`IgnitionSystemTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_Mfr_EngineConfig2` FOREIGN KEY (`EngineMfrID`)
        REFERENCES `mfr` (`MfrID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `aspirationengineconfig2_fk` FOREIGN KEY (`AspirationID`)
        REFERENCES `aspiration` (`AspirationID`),
    CONSTRAINT `cylinderheadtypeengineconfig2_fk` FOREIGN KEY (`CylinderHeadTypeID`)
        REFERENCES `cylinderheadtype` (`CylinderHeadTypeID`),
    CONSTRAINT `enginebaseengineconfig2_fk` FOREIGN KEY (`EngineBaseID`)
        REFERENCES `enginebase2` (`EngineBaseID`),
    CONSTRAINT `enginedesignationengineconfi2_fk` FOREIGN KEY (`EngineDesignationID`)
        REFERENCES `enginedesignation` (`EngineDesignationID`),
    CONSTRAINT `engineversionengineconfig2_fk` FOREIGN KEY (`EngineVersionID`)
        REFERENCES `engineversion` (`EngineVersionID`),
    CONSTRAINT `enginevinengineconfig2_fk` FOREIGN KEY (`EngineVINID`)
        REFERENCES `enginevin` (`EngineVINID`),
    CONSTRAINT `fueldeliveryconfigengineconf2_fk` FOREIGN KEY (`FuelDeliveryConfigID`)
        REFERENCES `fueldeliveryconfig` (`FuelDeliveryConfigID`),
    CONSTRAINT `fueltypeengineconfig2_fk` FOREIGN KEY (`FuelTypeID`)
        REFERENCES `fueltype` (`FuelTypeID`),
    CONSTRAINT `ignitionsystemtypeengineconf2_fk` FOREIGN KEY (`IgnitionSystemTypeID`)
        REFERENCES `ignitionsystemtype` (`IgnitionSystemTypeID`),
    CONSTRAINT `mfrengineconfig2_fk` FOREIGN KEY (`EngineMfrID`)
        REFERENCES `mfr` (`MfrID`)
);

CREATE TABLE `SpringType` (
    `SpringTypeID` INT(10) NOT NULL,
    `SpringTypeName` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`SpringTypeID`)
);
CREATE TABLE `SpringTypeConfig` (
    `SpringTypeConfigID` INT(10) NOT NULL,
    `FrontSpringTypeID` INT(10) NOT NULL,
    `RearSpringTypeID` INT(10) NOT NULL,
    PRIMARY KEY (`SpringTypeConfigID`),
    KEY `IDX_SpringTypeConfig_FrontSprin` (`FrontSpringTypeID`),
    KEY `IDX_SpringTypeConfig_RearSpring` (`RearSpringTypeID`),
    CONSTRAINT `FK_FrontSpringType_SpringTypeConfig` FOREIGN KEY (`FrontSpringTypeID`)
        REFERENCES `springtype` (`SpringTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_RearSpringType_SpringTypeConfig` FOREIGN KEY (`RearSpringTypeID`)
        REFERENCES `springtype` (`SpringTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `springconfig1_fk` FOREIGN KEY (`FrontSpringTypeID`)
        REFERENCES `springtype` (`SpringTypeID`),
    CONSTRAINT `springconfig2_fk` FOREIGN KEY (`RearSpringTypeID`)
        REFERENCES `springtype` (`SpringTypeID`)
);
CREATE TABLE `SteeringSystem` (
    `SteeringSystemID` INT(10) NOT NULL,
    `SteeringSystemName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`SteeringSystemID`)
);
CREATE TABLE `SteeringType` (
    `SteeringTypeID` INT(10) NOT NULL,
    `SteeringTypeName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`SteeringTypeID`)
);
CREATE TABLE `SteeringConfig` (
    `SteeringConfigID` INT(10) NOT NULL,
    `SteeringTypeID` INT(10) NOT NULL,
    `SteeringSystemID` INT(10) NOT NULL,
    PRIMARY KEY (`SteeringConfigID`),
    KEY `IDX_SteeringConfig_SteeringSyst` (`SteeringSystemID`),
    KEY `IDX_SteeringConfig_SteeringType` (`SteeringTypeID`),
    CONSTRAINT `FK_SteeringSystem_SteeringConfig` FOREIGN KEY (`SteeringSystemID`)
        REFERENCES `steeringsystem` (`SteeringSystemID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_SteeringType_SteeringConfig` FOREIGN KEY (`SteeringTypeID`)
        REFERENCES `steeringtype` (`SteeringTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `steeringsystemsteeringconfig_fk` FOREIGN KEY (`SteeringSystemID`)
        REFERENCES `steeringsystem` (`SteeringSystemID`),
    CONSTRAINT `steeringtypesteeringconfig_fk` FOREIGN KEY (`SteeringTypeID`)
        REFERENCES `steeringtype` (`SteeringTypeID`)
);

CREATE TABLE `TransmissionControlType` (
    `TransmissionControlTypeID` INT(10) NOT NULL,
    `TransmissionControlTypeName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`TransmissionControlTypeID`)
);
CREATE TABLE `TransmissionMfrCode` (
    `TransmissionMfrCodeID` INT(10) NOT NULL,
    `TransmissionMfrCode` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`TransmissionMfrCodeID`)
);
CREATE TABLE `TransmissionNumSpeeds` (
    `TransmissionNumSpeedsID` INT(10) NOT NULL,
    `TransmissionNumSpeeds` CHAR(3) NOT NULL,
    PRIMARY KEY (`TransmissionNumSpeedsID`)
);
CREATE TABLE `TransmissionType` (
    `TransmissionTypeID` INT(10) NOT NULL,
    `TransmissionTypeName` VARCHAR(30) NOT NULL,
    PRIMARY KEY (`TransmissionTypeID`)
);
CREATE TABLE `TransmissionBase` (
    `TransmissionBaseID` INT(10) NOT NULL,
    `TransmissionTypeID` INT(10) NOT NULL,
    `TransmissionNumSpeedsID` INT(10) NOT NULL,
    `TransmissionControlTypeID` INT(10) NOT NULL,
    PRIMARY KEY (`TransmissionBaseID`),
    KEY `IDX_TransmissionBase_Transmiss1` (`TransmissionControlTypeID`),
    KEY `IDX_TransmissionBase_Transmiss2` (`TransmissionNumSpeedsID`),
    KEY `IDX_TransmissionBase_Transmiss3` (`TransmissionTypeID`),
    CONSTRAINT `FK_TransmissionControlType_TransmissionBase` FOREIGN KEY (`TransmissionControlTypeID`)
        REFERENCES `transmissioncontroltype` (`TransmissionControlTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_TransmissionNumSpeeds_TransmissionBase` FOREIGN KEY (`TransmissionNumSpeedsID`)
        REFERENCES `transmissionnumspeeds` (`TransmissionNumSpeedsID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_TransmissionType_TransmissionBase` FOREIGN KEY (`TransmissionTypeID`)
        REFERENCES `transmissiontype` (`TransmissionTypeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `transmissioncontroltypetrans_fk` FOREIGN KEY (`TransmissionControlTypeID`)
        REFERENCES `transmissioncontroltype` (`TransmissionControlTypeID`),
    CONSTRAINT `transmissionnumspeedstransmi_fk` FOREIGN KEY (`TransmissionNumSpeedsID`)
        REFERENCES `transmissionnumspeeds` (`TransmissionNumSpeedsID`),
    CONSTRAINT `transmissiontypetransmission_fk` FOREIGN KEY (`TransmissionTypeID`)
        REFERENCES `transmissiontype` (`TransmissionTypeID`)
);
CREATE TABLE `Transmission` (
    `TransmissionID` INT(10) NOT NULL,
    `TransmissionBaseID` INT(10) NOT NULL,
    `TransmissionMfrCodeID` INT(10) NOT NULL,
    `TransmissionElecControlledID` INT(10) NOT NULL,
    `TransmissionMfrID` INT(10) NOT NULL,
    PRIMARY KEY (`TransmissionID`),
    KEY `IDX_Transmission_TransmissionBa` (`TransmissionBaseID`),
    KEY `IDX_Transmission_TransmissionM1` (`TransmissionMfrCodeID`),
    KEY `IDX_Transmission_TransmissionM2` (`TransmissionMfrID`),
    KEY `FK_Transmission_ElecControlled` (`TransmissionElecControlledID`),
    CONSTRAINT `FK_Mfr_Transmission` FOREIGN KEY (`TransmissionMfrID`)
        REFERENCES `mfr` (`MfrID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_TransmissionBase_Transmission` FOREIGN KEY (`TransmissionBaseID`)
        REFERENCES `transmissionbase` (`TransmissionBaseID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_TransmissionMfrCode_Transmission` FOREIGN KEY (`TransmissionMfrCodeID`)
        REFERENCES `transmissionmfrcode` (`TransmissionMfrCodeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `FK_Transmission_ElecControlled` FOREIGN KEY (`TransmissionElecControlledID`)
        REFERENCES `eleccontrolled` (`ElecControlledID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `mfrtransmission_fk` FOREIGN KEY (`TransmissionMfrID`)
        REFERENCES `mfr` (`MfrID`),
    CONSTRAINT `transmissionbasetransmission_fk` FOREIGN KEY (`TransmissionBaseID`)
        REFERENCES `transmissionbase` (`TransmissionBaseID`),
    CONSTRAINT `transmissionmfrcodetransmiss_fk` FOREIGN KEY (`TransmissionMfrCodeID`)
        REFERENCES `transmissionmfrcode` (`TransmissionMfrCodeID`)
);
CREATE TABLE `WheelBase` (
    `WheelBaseID` INT(10) NOT NULL,
    `WheelBase` VARCHAR(10) NOT NULL,
    `WheelBaseMetric` VARCHAR(10) NOT NULL,
    PRIMARY KEY (`WheelBaseID`)
);
CREATE TABLE `VehicleToBedConfig` (
    `VehicleToBedConfigID` INT(10) NOT NULL,
    `VehicleID` INT(10) NOT NULL,
    `BedConfigID` INT(10) NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleToBedConfigID`),
    KEY `IDX_VehicleToBedConfig_BedConfi` (`BedConfigID`),
    KEY `IDX_VehicleToBedConfig_VehicleID` (`VehicleID`),
    CONSTRAINT `bedconfigvehicletobed_fk` FOREIGN KEY (`BedConfigID`)
        REFERENCES `bedconfig` (`BedConfigID`),
    CONSTRAINT `vehiclevehicle_fk` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`)
);
CREATE TABLE `VehicleToBodyStyleConfig` (
    `VehicleToBodyStyleConfigID` INT(10) NOT NULL,
    `VehicleID` INT(10) NOT NULL,
    `BodyStyleConfigID` INT(10) NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleToBodyStyleConfigID`),
    KEY `IDX_VehicleToBodyStyleConfig_Bo` (`BodyStyleConfigID`),
    KEY `IDX_VehicleToBodyStyleConfig_Ve` (`VehicleID`),
    CONSTRAINT `bodystyleconfigbasetosubmode_fk` FOREIGN KEY (`BodyStyleConfigID`)
        REFERENCES `bodystyleconfig` (`BodyStyleConfigID`),
    CONSTRAINT `vehicletobodystyleconfigvehicle_fk` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`)
);
CREATE TABLE `VehicleToDriveType` (
    `VehicleToDriveTypeID` INT(10) NOT NULL,
    `VehicleID` INT(10) NOT NULL,
    `DriveTypeID` INT(10) NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleToDriveTypeID`),
    KEY `IDX_VehicleToDriveType_DriveTyp` (`DriveTypeID`),
    KEY `IDX_VehicleToDriveType_VehicleID` (`VehicleID`),
    CONSTRAINT `drivetypevehicletodri_fk` FOREIGN KEY (`DriveTypeID`)
        REFERENCES `drivetype` (`DriveTypeID`),
    CONSTRAINT `vehicletodrivetypevehicle_fk` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`)
);
CREATE TABLE `VehicleToEngineConfig` (
    `VehicleToEngineConfigID` INT(10) NOT NULL,
    `VehicleID` INT(10) NOT NULL,
    `EngineConfigID` INT(10) NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleToEngineConfigID`),
    KEY `IDX_VehicleToEngineConfig_Engin` (`EngineConfigID`),
    KEY `IDX_VehicleToEngineConfig_Vehic` (`VehicleID`),
    CONSTRAINT `engineconfigvehicleto_fk` FOREIGN KEY (`EngineConfigID`)
        REFERENCES `engineconfig2` (`EngineConfigID`),
    CONSTRAINT `vehicletoengineconfigvehicle_fk` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`)
);
CREATE TABLE `VehicleToMfrBodyCode` (
    `VehicleToMfrBodyCodeID` INT(10) NOT NULL,
    `VehicleID` INT(10) NOT NULL,
    `MfrBodyCodeID` INT(10) NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleToMfrBodyCodeID`),
    KEY `IDX_VehicleToMfrBodyCode_MfrBod` (`MfrBodyCodeID`),
    KEY `IDX_VehicleToMfrBodyCode_Vehicl` (`VehicleID`),
    CONSTRAINT `mfrbodycodevehicletom_fk` FOREIGN KEY (`MfrBodyCodeID`)
        REFERENCES `mfrbodycode` (`MfrBodyCodeID`),
    CONSTRAINT `vehicletomfrbodycodevehicle_fk` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`)
);
CREATE TABLE `VehicleToSpringTypeConfig` (
    `VehicleToSpringTypeConfigID` INT(10) NOT NULL,
    `VehicleID` INT(10) NOT NULL,
    `SpringTypeConfigID` INT(10) NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleToSpringTypeConfigID`),
    KEY `IDX_VehicleToSpringTypeConfig_S` (`SpringTypeConfigID`),
    KEY `IDX_VehicleToSpringTypeConfig_V` (`VehicleID`),
    CONSTRAINT `vehicletospringtype1_fk` FOREIGN KEY (`SpringTypeConfigID`)
        REFERENCES `springtypeconfig` (`SpringTypeConfigID`),
    CONSTRAINT `vehicletospringtypeconfigvehicle_fk` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`)
);
CREATE TABLE `VehicleToSteeringConfig` (
    `VehicleToSteeringConfigID` INT(10) NOT NULL,
    `VehicleID` INT(10) NOT NULL,
    `SteeringConfigID` INT(10) NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleToSteeringConfigID`),
    KEY `IDX_VehicleToSteeringConfig_Ste` (`SteeringConfigID`),
    KEY `IDX_VehicleToSteeringConfig_Veh` (`VehicleID`),
    CONSTRAINT `steeringconfigvehicle_fk` FOREIGN KEY (`SteeringConfigID`)
        REFERENCES `steeringconfig` (`SteeringConfigID`),
    CONSTRAINT `vehicletosteeringconfigvehicle_fk` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`)
);
CREATE TABLE `VehicleToTransmission` (
    `VehicleToTransmissionID` INT(10) NOT NULL,
    `VehicleID` INT(10) NOT NULL,
    `TransmissionID` INT(10) NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleToTransmissionID`),
    KEY `IDX_VehicleToTransmission_Trans` (`TransmissionID`),
    KEY `IDX_VehicleToTransmission_Vehic` (`VehicleID`),
    CONSTRAINT `transmissionvehicleto_fk` FOREIGN KEY (`TransmissionID`)
        REFERENCES `transmission` (`TransmissionID`),
    CONSTRAINT `vehicletotransmissionvehicle_fk` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`)
);
CREATE TABLE `VehicleToWheelbase` (
    `VehicleToWheelbaseID` INT(10) NOT NULL,
    `VehicleID` INT(10) NOT NULL,
    `WheelbaseID` INT(10) NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleToWheelbaseID`),
    KEY `IDX_VehicleToWheelbase_VehicleID` (`VehicleID`),
    KEY `IDX_VehicleToWheelbase_Wheelbas` (`WheelbaseID`),
    CONSTRAINT `vehicletowheelbasevehicle_fk` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`)
);

CREATE TABLE `VehicleToClass` (
	`VehicleToClassID` int NOT NULL,
	`VehicleID` int NOT NULL,
	`ClassID` int NOT NULL,
	`Source` varchar(10) DEFAULT NULL,
 CONSTRAINT `PK_VehicleToClass` PRIMARY KEY 
(
	`VehicleToClassID` ASC
),
KEY `IDX_VehicleToClass_VehicleID` (`VehicleID`),
KEY `IDX_VehicleToClass_ClassID` (`ClassID`),
    CONSTRAINT `classvehicle_fk` FOREIGN KEY (`ClassID`)
        REFERENCES `Class` (`ClassID`),
    CONSTRAINT `vehicletoclassvehicle_FK` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`)
);
CREATE TABLE `VehicleToBodyConfig` (
	`VehicleToBodyConfigID` int NOT NULL,
	`VehicleID` int NOT NULL,
	`WheelBaseID` int NOT NULL,
	`BedConfigID` int NOT NULL,
	`BodyStyleConfigID` int NOT NULL,
	`MfrBodyCodeID` int NOT NULL,
    `Source` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`VehicleToBodyConfigID`),
    KEY `IDX_VehicleToBodyConfig_VehicleID` (`VehicleID`),
	KEY `IDX_VehicleToBodyConfig_BodyStyleConfigID` (`BodyStyleConfigID`),
	KEY `IDX_VehicleToBodyConfig_BedConfigID` (`BedConfigID`),
	KEY `IDX_VehicleToBodyConfig_MfrBodyCodeID` (`MfrBodyCodeID`),
    KEY `IDX_VehicleToBodyConfig_WheelbaseID` (`WheelbaseID`),
    CONSTRAINT `vehicletobodyconfigvehicle_fk` FOREIGN KEY (`VehicleID`)
        REFERENCES `vehicle` (`VehicleID`),
    CONSTRAINT `vehicletobodyconfigbodystyleconfig_fk` FOREIGN KEY (`BodyStyleConfigID`)
        REFERENCES `BodyStyleConfig` (`BodyStyleConfigID`),
    CONSTRAINT `vehicletobodyconfigbedconfig_fk` FOREIGN KEY (`BedConfigID`)
        REFERENCES `BedConfig` (`BedConfigID`),
    CONSTRAINT `vehicletobodyconfigMfrbodycode_fk` FOREIGN KEY (`MfrBodyCodeID`)
        REFERENCES `MfrBodyCode` (`MfrBodyCodeID`),
    CONSTRAINT `vehicletobodyconfigwheelbase_fk` FOREIGN KEY (`WheelbaseID`)
        REFERENCES `Wheelbase` (`WheelbaseID`)
);




CREATE TABLE `ChangeAttributeStates`(
	`ChangeAttributeStateID` int NOT NULL ,
	`ChangeAttributeState` varchar(255) NOT NULL,
PRIMARY KEY(`ChangeAttributeStateID`)
);

CREATE TABLE `ChangeReasons`(
	`ChangeReasonID` int NOT NULL,
	`ChangeReason` varchar(255) NOT NULL,
    PRIMARY KEY (`ChangeReasonID`)
);

CREATE TABLE `ChangeTableNames`(
	`TableNameID` int NOT NULL,
	`TableName` varchar(255) NOT NULL,
	`TableDescription` varchar(1000) NULL,
    PRIMARY KEY (`TableNameID`)
);
CREATE TABLE `Changes`(
	`ChangeID` int NOT NULL AUTO_INCREMENT,
	`RequestID` int NOT NULL,
	`ChangeReasonID` int NOT NULL,
	`RevDate` datetime NULL,
    PRIMARY KEY(`ChangeID`),
    KEY `IDX_Changes_ChangeReason_ChangeReasonID` (`ChangeReasonID`),
    CONSTRAINT `FK_ChangeReason_Changes` FOREIGN KEY (`ChangeReasonID`)
        REFERENCES `changereasons` (`ChangeReasonID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION
);

CREATE TABLE `ChangeDetails`(
	`ChangeDetailID` int NOT NULL AUTO_INCREMENT,
	`ChangeID` int NOT NULL,
	`ChangeAttributeStateID` int NOT NULL,
	`TableNameID` int NOT NULL,
	`PrimaryKeyColumnName` varchar(255) NULL,
	`PrimaryKeyBefore` int NULL,
	`PrimaryKeyAfter` int NULL,
	`ColumnName` varchar(255) NULL,
	`ColumnValueBefore` varchar(1000) NULL,
	`ColumnValueAfter` varchar(1000) NULL,
    PRIMARY KEY (`ChangeDetailID`),
	KEY `IDX_ChangeDetails_Changes_ChangeID` (`ChangeID`),
    KEY `IDX_ChangeDetails_ChangeAttributeStates_ChangeAttributeStateID` (`ChangeAttributeStateID`),
    KEY `IDX_ChangeDetails_ChangeTableNames_TableNameID` (`TableNameID`),
    CONSTRAINT `FK_Changes_ChangeDetails` FOREIGN KEY (`ChangeID`)
        REFERENCES `changes` (`ChangeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
	CONSTRAINT `FK_ChangeAttributeStates_ChangeDetails` FOREIGN KEY (`ChangeAttributeStateID`)
		REFERENCES `changeattributestates` (`ChangeAttributeStateID`)
		ON DELETE NO ACTION ON UPDATE NO ACTION,
	CONSTRAINT `FK_ChangeTableNames_ChangeDetails` FOREIGN KEY (`TableNameID`)
		REFERENCES `changetablenames` (`TableNameID`)
		ON DELETE NO ACTION ON UPDATE NO ACTION    
    
);

CREATE TABLE Version(
	VersionDate date NOT NULL
);

CREATE TABLE VCdbChanges(
	VersionDate datetime NOT NULL,
	TableName varchar(30) NOT NULL,
	ID int NOT NULL,
	Action varchar(1) NOT NULL
) 
;

CREATE TABLE Attachment(

	AttachmentID int  NOT NULL AUTO_InCREMENT,

	AttachmentTypeID int NOT NULL,

	AttachmentFileName varchar(50) NOT NULL,

	AttachmentURL varchar(100) NOT NULL,

	AttachmentDescription varchar(50) NOT NULL,
    Primary key (AttachmentID)
	)

;

CREATE TABLE AttachmentType(

	AttachmentTypeID int  NOT NULL AUTO_INCREMENT,

	AttachmentTypeName varchar(20) NOT NULL,
    Primary key(AttachmentTypeID)
	)

;

CREATE TABLE EnglishPhrase(

	EnglishPhraseID int  NOT NULL AUTO_INCREMENT,

	EnglishPhrase varchar(100) NOT NULL,
    Primary key(EnglishPhraseID)
	)

;

CREATE TABLE Language(

	LanguageID int NOT NULL AUTO_INCREMENT,

	LanguageName varchar(20) NOT NULL,

	DialectName varchar(20) NULL,
    
    Primary key(LanguageID)
	)

;

CREATE TABLE LanguageTranslation(

	LanguageTranslationID int  NOT NULL Auto_Increment,

	EnglishPhraseID int NOT NULL,

	LanguageID int NOT NULL,

	Translation varchar(150) NOT NULL,
    
    Primary KEY (LanguageTranslationID)
	)

;

CREATE TABLE LanguageTranslationAttachment(

	LanguageTranslationAttachmentID int NOT NULL Auto_Increment,

	LanguageTranslationID int NOT NULL,

	AttachmentID int NOT NULL,
    
    Primary key(LanguageTranslationAttachmentID)
	
	)

;
