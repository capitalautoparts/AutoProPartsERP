CREATE TABLE "Abbreviation"(
	"Abbreviation" varchar(3) NOT NULL,
	"Description" varchar(20) NOT NULL,
	"LongDescription" varchar(200) NOT NULL,
  PRIMARY KEY ("Abbreviation")
 );

CREATE TABLE "VehicleTypeGroup" (
    "VehicleTypeGroupID" INT NOT NULL,
    "VehicleTypeGroupName" VARCHAR(50) NOT NULL	
);

CREATE TABLE "VehicleType" (
    "VehicleTypeID" INT NOT NULL,
    "VehicleTypeName" VARCHAR(50) NOT NULL,
    "VehicleTypeGroupID" INT DEFAULT NULL,
    PRIMARY KEY ("VehicleTypeID")
);

CREATE TABLE "Region" (
    "RegionID" INT NOT NULL,
    "ParentID" INT DEFAULT NULL,
    "RegionAbbr" VARCHAR(3) DEFAULT NULL,
    "RegionName" VARCHAR(30) DEFAULT NULL,
    PRIMARY KEY ("RegionID"),
    CONSTRAINT "FK_Region_Parent" FOREIGN KEY ("ParentID")
        REFERENCES "Region" ("RegionID")
        ON DELETE NO ACTION ON UPDATE NO ACTION
);

CREATE TABLE "Aspiration" (
    "AspirationID" INT NOT NULL,
    "AspirationName" VARCHAR(30) NOT NULL,
    PRIMARY KEY ("AspirationID")
);

CREATE TABLE "CylinderHeadType" (
    "CylinderHeadTypeID" INT NOT NULL,
    "CylinderHeadTypeName" VARCHAR(30) NOT NULL,
    PRIMARY KEY ("CylinderHeadTypeID")
);

CREATE TABLE "EngineBlock" (
    "EngineBlockID" INT NOT NULL,
    "Liter" VARCHAR(6) NOT NULL,
    "CC" VARCHAR(8) NOT NULL,
    "CID" VARCHAR(7) NOT NULL,
    "Cylinders" VARCHAR(2) NOT NULL,
    "BlockType" VARCHAR(2) NOT NULL,
	    PRIMARY KEY ("EngineBlockID")
	);	
	
CREATE TABLE "EngineBoreStroke" (
    "EngineBoreStrokeID" INT NOT NULL,
    "EngBoreIn" VARCHAR(10) NOT NULL,
    "EngBoreMetric" VARCHAR(10) NOT NULL,
    "EngStrokeIn" VARCHAR(10) NOT NULL,
    "EngStrokeMetric" VARCHAR(10) NOT NULL,
	    PRIMARY KEY ("EngineBoreStrokeID")
	);	
	
CREATE TABLE "EngineBase2" (
    "EngineBaseID" INT NOT NULL,
    "EngineBlockID" INT NOT NULL,
    "EngineBoreStrokeID" INT NOT NULL,
        PRIMARY KEY ("EngineBaseID"),
    CONSTRAINT "EngineBaseEngineBlock_fk" FOREIGN KEY ("EngineBlockID")
        REFERENCES "EngineBlock" ("EngineBlockID"),
	CONSTRAINT "EngineBaseEngineBoreStroke_fk" FOREIGN KEY ("EngineBoreStrokeID")
        REFERENCES "EngineBoreStroke" ("EngineBoreStrokeID")
);	
	
CREATE TABLE "EngineBase" (
    "EngineBaseID" INT NOT NULL,
    "Liter" VARCHAR(6) NOT NULL,
    "CC" VARCHAR(8) NOT NULL,
    "CID" VARCHAR(7) NOT NULL,
    "Cylinders" VARCHAR(2) NOT NULL,
    "BlockType" VARCHAR(2) NOT NULL,
    "EngBoreIn" VARCHAR(10) NOT NULL,
    "EngBoreMetric" VARCHAR(10) NOT NULL,
    "EngStrokeIn" VARCHAR(10) NOT NULL,
    "EngStrokeMetric" VARCHAR(10) NOT NULL,
    PRIMARY KEY ("EngineBaseID")
);

CREATE TABLE "EngineDesignation" (
    "EngineDesignationID" INT NOT NULL,
    "EngineDesignationName" VARCHAR(30) NOT NULL,
    PRIMARY KEY ("EngineDesignationID")
);

CREATE TABLE "EngineVersion" (
    "EngineVersionID" INT NOT NULL,
    "EngineVersion" VARCHAR(20) NOT NULL,
    PRIMARY KEY ("EngineVersionID")
);
CREATE TABLE "EngineVIN" (
    "EngineVINID" INT NOT NULL,
    "EngineVINName" VARCHAR(5) NOT NULL,
    PRIMARY KEY ("EngineVINID")
);
CREATE TABLE "FuelDeliverySubType" (
    "FuelDeliverySubTypeID" INT NOT NULL,
    "FuelDeliverySubTypeName" VARCHAR(50) NOT NULL,
    PRIMARY KEY ("FuelDeliverySubTypeID")
);
CREATE TABLE "FuelDeliveryType" (
    "FuelDeliveryTypeID" INT NOT NULL,
    "FuelDeliveryTypeName" VARCHAR(50) NOT NULL,
    PRIMARY KEY ("FuelDeliveryTypeID")
);
CREATE TABLE "FuelSystemControlType" (
    "FuelSystemControlTypeID" INT NOT NULL,
    "FuelSystemControlTypeName" VARCHAR(50) NOT NULL,
    PRIMARY KEY ("FuelSystemControlTypeID")
);
CREATE TABLE "FuelSystemDesign" (
    "FuelSystemDesignID" INT NOT NULL,
    "FuelSystemDesignName" VARCHAR(50) NOT NULL,
    PRIMARY KEY ("FuelSystemDesignID")
);
CREATE TABLE "FuelDeliveryConfig" (
    "FuelDeliveryConfigID" INT NOT NULL,
    "FuelDeliveryTypeID" INT NOT NULL,
    "FuelDeliverySubTypeID" INT NOT NULL,
    "FuelSystemControlTypeID" INT NOT NULL,
    "FuelSystemDesignID" INT NOT NULL,
    PRIMARY KEY ("FuelDeliveryConfigID"),
    CONSTRAINT "FK_FuelDeliverySubType_FuelDeliveryConfig" FOREIGN KEY ("FuelDeliverySubTypeID")
        REFERENCES "FuelDeliverySubType" ("FuelDeliverySubTypeID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_FuelDeliveryType_FuelDeliveryConfig" FOREIGN KEY ("FuelDeliveryTypeID")
        REFERENCES "FuelDeliveryType" ("FuelDeliveryTypeID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_FuelSystemControlType_FuelDeliveryConfig" FOREIGN KEY ("FuelSystemControlTypeID")
        REFERENCES "FuelSystemControlType" ("FuelSystemControlTypeID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_FuelSystemDesign_FuelDeliveryConfig" FOREIGN KEY ("FuelSystemDesignID")
        REFERENCES "FuelSystemDesign" ("FuelSystemDesignID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "fueldeliverysubtypefueldeliv_fk" FOREIGN KEY ("FuelDeliverySubTypeID")
        REFERENCES "FuelDeliverySubType" ("FuelDeliverySubTypeID"),
    CONSTRAINT "fueldeliverytypefueldelivery_fk" FOREIGN KEY ("FuelDeliveryTypeID")
        REFERENCES "FuelDeliveryType" ("FuelDeliveryTypeID"),
    CONSTRAINT "fuelsystemcontroltypefueldel_fk" FOREIGN KEY ("FuelSystemControlTypeID")
        REFERENCES "FuelSystemControlType" ("FuelSystemControlTypeID"),
    CONSTRAINT "fuelsystemdesignfueldelivery_fk" FOREIGN KEY ("FuelSystemDesignID")
        REFERENCES "FuelSystemDesign" ("FuelSystemDesignID")
);
CREATE TABLE "FuelType" (
    "FuelTypeID" INT NOT NULL,
    "FuelTypeName" VARCHAR(30) NOT NULL,
    PRIMARY KEY ("FuelTypeID")
);
CREATE TABLE "IgnitionSystemType" (
    "IgnitionSystemTypeID" INT NOT NULL,
    "IgnitionSystemTypeName" VARCHAR(30) NOT NULL,
    PRIMARY KEY ("IgnitionSystemTypeID")
);


CREATE TABLE "Mfr" (
    "MfrID" INT NOT NULL,
    "MfrName" VARCHAR(30) NOT NULL,
    PRIMARY KEY ("MfrID")
);

CREATE TABLE "PowerOutput" (
    "PowerOutputID" INT NOT NULL,
    "HorsePower" VARCHAR(10) NOT NULL,
    "KilowattPower" VARCHAR(10) NOT NULL
);
CREATE TABLE "Valves" (
    "ValvesID" INT NOT NULL,
    "ValvesPerEngine" VARCHAR(3) NOT NULL,
    PRIMARY KEY ("ValvesID")
);
CREATE TABLE "EngineConfig" (
    "EngineConfigID" INT NOT NULL,
    "EngineDesignationID" INT NOT NULL,
    "EngineVINID" INT NOT NULL,
    "ValvesID" INT NOT NULL,
    "EngineBaseID" INT NOT NULL,
    "FuelDeliveryConfigID" INT NOT NULL,
    "AspirationID" INT NOT NULL,
    "CylinderHeadTypeID" INT NOT NULL,
    "FuelTypeID" INT NOT NULL,
    "IgnitionSystemTypeID" INT NOT NULL,
    "EngineMfrID" INT NOT NULL,
    "EngineVersionID" INT NOT NULL,
    "PowerOutputID" INT NOT NULL DEFAULT '1',
    PRIMARY KEY ("EngineConfigID"),
    CONSTRAINT "FK_Aspiration_EngineConfig" FOREIGN KEY ("AspirationID")
        REFERENCES "Aspiration" ("AspirationID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_CylinderHeadType_EngineConfig" FOREIGN KEY ("CylinderHeadTypeID")
        REFERENCES "CylinderHeadType" ("CylinderHeadTypeID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineBase_EngineConfig" FOREIGN KEY ("EngineBaseID")
        REFERENCES "EngineBase" ("EngineBaseID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineConfig_Valves" FOREIGN KEY ("ValvesID")
        REFERENCES "Valves" ("ValvesID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineConfig_Valves1" FOREIGN KEY ("ValvesID")
        REFERENCES "Valves" ("ValvesID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineDesignation_EngineConfig" FOREIGN KEY ("EngineDesignationID")
        REFERENCES "EngineDesignation" ("EngineDesignationID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineVIN_EngineConfig" FOREIGN KEY ("EngineVINID")
        REFERENCES "EngineVIN" ("EngineVINID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineVersion_EngineConfig" FOREIGN KEY ("EngineVersionID")
        REFERENCES "EngineVersion" ("EngineVersionID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_FuelDeliveryConfig_EngineConfig" FOREIGN KEY ("FuelDeliveryConfigID")
        REFERENCES "FuelDeliveryConfig" ("FuelDeliveryConfigID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_FuelType_EngineConfig" FOREIGN KEY ("FuelTypeID")
        REFERENCES "FuelType" ("FuelTypeID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_IgnitionSystemType_EngineConfig" FOREIGN KEY ("IgnitionSystemTypeID")
        REFERENCES "IgnitionSystemType" ("IgnitionSystemTypeID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_Mfr_EngineConfig" FOREIGN KEY ("EngineMfrID")
        REFERENCES "Mfr" ("MfrID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "AspirationEngineConfig_fk" FOREIGN KEY ("AspirationID")
        REFERENCES "Aspiration" ("AspirationID"),
    CONSTRAINT "CylinderHeadTypeEngineConfig_fk" FOREIGN KEY ("CylinderHeadTypeID")
        REFERENCES "CylinderHeadType" ("CylinderHeadTypeID"),
    CONSTRAINT "EngineBaseEngineConfig_fk" FOREIGN KEY ("EngineBaseID")
        REFERENCES "EngineBase" ("EngineBaseID"),
    CONSTRAINT "EngineDesignationengineconfi_fk" FOREIGN KEY ("EngineDesignationID")
        REFERENCES "EngineDesignation" ("EngineDesignationID"),
    CONSTRAINT "EngineVersionEngineConfig_fk" FOREIGN KEY ("EngineVersionID")
        REFERENCES "EngineVersion" ("EngineVersionID"),
    CONSTRAINT "EngineVINEngineConfig_fk" FOREIGN KEY ("EngineVINID")
        REFERENCES "EngineVIN" ("EngineVINID"),
    CONSTRAINT "FuelDeliveryConfigengineconf_fk" FOREIGN KEY ("FuelDeliveryConfigID")
        REFERENCES "FuelDeliveryConfig" ("FuelDeliveryConfigID"),
    CONSTRAINT "FuelTypeEngineConfig_fk" FOREIGN KEY ("FuelTypeID")
        REFERENCES "FuelType" ("FuelTypeID"),
    CONSTRAINT "IgnitionSystemTypeengineconf_fk" FOREIGN KEY ("IgnitionSystemTypeID")
        REFERENCES "IgnitionSystemType" ("IgnitionSystemTypeID"),
    CONSTRAINT "MfrEngineConfig_fk" FOREIGN KEY ("EngineMfrID")
        REFERENCES "Mfr" ("MfrID")
);
CREATE TABLE "EngineConfig2" (
    "EngineConfigID" INT NOT NULL,
    "EngineDesignationID" INT NOT NULL,
    "EngineVINID" INT NOT NULL,
    "ValvesID" INT NOT NULL,
    "EngineBaseID" INT NOT NULL,
	"EngineBlockID" INT NOT NULL,
    "EngineBoreStrokeID" INT NOT NULL,
    "FuelDeliveryConfigID" INT NOT NULL,
    "AspirationID" INT NOT NULL,
    "CylinderHeadTypeID" INT NOT NULL,
    "FuelTypeID" INT NOT NULL,
    "IgnitionSystemTypeID" INT NOT NULL,
    "EngineMfrID" INT NOT NULL,
    "EngineVersionID" INT NOT NULL,
    "PowerOutputID" INT NOT NULL DEFAULT '1',
    PRIMARY KEY ("EngineConfigID"),
    CONSTRAINT "FK_Aspiration_EngineConfig2" FOREIGN KEY ("AspirationID")
        REFERENCES "Aspiration" ("AspirationID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_CylinderHeadType_EngineConfig2" FOREIGN KEY ("CylinderHeadTypeID")
        REFERENCES "CylinderHeadType" ("CylinderHeadTypeID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineBase_EngineConfig2" FOREIGN KEY ("EngineBaseID")
        REFERENCES "EngineBase2" ("EngineBaseID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
		    CONSTRAINT "FK_EngineBlock_EngineConfig2" FOREIGN KEY ("EngineBlockID")
        REFERENCES "EngineBlock" ("EngineBlockID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
		    CONSTRAINT "FK_EngineBoreStroke_EngineConfig2" FOREIGN KEY ("EngineBoreStrokeID")
        REFERENCES "EngineBoreStroke" ("EngineBoreStrokeID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineConfig2_Valves" FOREIGN KEY ("ValvesID")
        REFERENCES "Valves" ("ValvesID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineConfig2_Valves1" FOREIGN KEY ("ValvesID")
        REFERENCES "Valves" ("ValvesID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineDesignation_EngineConfig2" FOREIGN KEY ("EngineDesignationID")
        REFERENCES "EngineDesignation" ("EngineDesignationID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineVIN_EngineConfig2" FOREIGN KEY ("EngineVINID")
        REFERENCES "EngineVIN" ("EngineVINID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_EngineVersion_EngineConfig2" FOREIGN KEY ("EngineVersionID")
        REFERENCES "EngineVersion" ("EngineVersionID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_FuelDeliveryConfig_EngineConfig2" FOREIGN KEY ("FuelDeliveryConfigID")
        REFERENCES "FuelDeliveryConfig" ("FuelDeliveryConfigID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_FuelType_EngineConfig2" FOREIGN KEY ("FuelTypeID")
        REFERENCES "FuelType" ("FuelTypeID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_IgnitionSystemType_EngineConfig2" FOREIGN KEY ("IgnitionSystemTypeID")
        REFERENCES "IgnitionSystemType" ("IgnitionSystemTypeID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "FK_Mfr_EngineConfig2" FOREIGN KEY ("EngineMfrID")
        REFERENCES "Mfr" ("MfrID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT "AspirationEngineConfig2_fk" FOREIGN KEY ("AspirationID")
        REFERENCES "Aspiration" ("AspirationID"),
    CONSTRAINT "CylinderHeadTypeEngineConfig2_fk" FOREIGN KEY ("CylinderHeadTypeID")
        REFERENCES "CylinderHeadType" ("CylinderHeadTypeID"),
    CONSTRAINT "EngineBaseEngineConfig2_fk" FOREIGN KEY ("EngineBaseID")
        REFERENCES "EngineBase2" ("EngineBaseID"),
    CONSTRAINT "EngineDesignationengineconfi2_fk" FOREIGN KEY ("EngineDesignationID")
        REFERENCES "EngineDesignation" ("EngineDesignationID"),
    CONSTRAINT "EngineVersionEngineConfig2_fk" FOREIGN KEY ("EngineVersionID")
        REFERENCES "EngineVersion" ("EngineVersionID"),
    CONSTRAINT "EngineVINEngineConfig2_fk" FOREIGN KEY ("EngineVINID")
        REFERENCES "EngineVIN" ("EngineVINID"),
    CONSTRAINT "FuelDeliveryConfigengineconf2_fk" FOREIGN KEY ("FuelDeliveryConfigID")
        REFERENCES "FuelDeliveryConfig" ("FuelDeliveryConfigID"),
    CONSTRAINT "FuelTypeEngineConfig2_fk" FOREIGN KEY ("FuelTypeID")
        REFERENCES "FuelType" ("FuelTypeID"),
    CONSTRAINT "IgnitionSystemTypeengineconf2_fk" FOREIGN KEY ("IgnitionSystemTypeID")
        REFERENCES "IgnitionSystemType" ("IgnitionSystemTypeID"),
    CONSTRAINT "MfrEngineConfig2_fk" FOREIGN KEY ("EngineMfrID")
        REFERENCES "Mfr" ("MfrID")
);


CREATE TABLE "EquipmentModel" (
	"EquipmentModelID" int NOT NULL,
	"EquipmentModelName" varchar(100) NOT NULL,

 CONSTRAINT "PK_EquipmentModel" PRIMARY KEY 
(
	"EquipmentModelID" 
)
);

CREATE TABLE "EquipmentBase" (
	"EquipmentBaseID" int NOT NULL,
	"MfrID" int NOT NULL,
	"EquipmentModelID" int NOT NULL,	
	"VehicleTypeID" int NOT NULL,

 CONSTRAINT "PK_EquipmentBase" PRIMARY KEY 
(
	"EquipmentBaseID" 
),
    CONSTRAINT "EquipmentBaseEquipmentModel_fk" FOREIGN KEY ("EquipmentModelID")
        REFERENCES "EquipmentModel" ("EquipmentModelID"),
    CONSTRAINT "EquipmentBaseEquipmentMfr_FK" FOREIGN KEY ("MfrID")
        REFERENCES "Mfr" ("MfrID"),
    CONSTRAINT "EquipmentBaseVehicleType_FK" FOREIGN KEY ("VehicleTypeID")
        REFERENCES "VehicleType" ("VehicleTypeID")

);

 CREATE TABLE "Equipment" (
	"EquipmentID" int NOT NULL,
	"EquipmentBaseID" int NOT NULL,
	"RegionID" int NOT NULL,
	"ProductionStart" varchar(10) NULL,
	"ProductionEnd" varchar(10) NULL,

 CONSTRAINT "PK_Equipment" PRIMARY KEY 
(
	"EquipmentID" 
),
    CONSTRAINT "FK_EquipmentBase_Equipment" FOREIGN KEY ("EquipmentBaseID")
        REFERENCES "EquipmentBase" ("EquipmentBaseID"),
    CONSTRAINT "FK_Region_Equipment" FOREIGN KEY ("RegionID")
        REFERENCES "Region" ("RegionID")
);

 CREATE TABLE "EquipmentToEngineConfig" (
	"EquipmentToEngineConfigID" int NOT NULL,
	"EquipmentID" int NOT NULL,
	"EngineConfigID" int NOT NULL,

 CONSTRAINT "PK_EquipmentToEngineConfig" PRIMARY KEY 
(
	"EquipmentToEngineConfigID" 
),
    CONSTRAINT "FK_EngineConfig_EquipmentToEngineConfig" FOREIGN KEY ("EngineConfigID")
        REFERENCES "EngineConfig2" ("EngineConfigID"),
    CONSTRAINT "FK_Equipment_EquipmentToEngineConfig" FOREIGN KEY ("EquipmentID")
        REFERENCES "Equipment" ("EquipmentID")
);



CREATE TABLE "ChangeAttributeStates"(
	"ChangeAttributeStateID" int NOT NULL ,
	"ChangeAttributeState" varchar(255) NOT NULL,
PRIMARY KEY("ChangeAttributeStateID")
);

CREATE TABLE "ChangeReasons"(
	"ChangeReasonID" int NOT NULL,
	"ChangeReason" varchar(255) NOT NULL,
    PRIMARY KEY ("ChangeReasonID")
);

CREATE TABLE "ChangeTableNames"(
	"TableNameID" int NOT NULL,
	"TableName" varchar(255) NOT NULL,
	"TableDescription" varchar(1000) NULL,
    PRIMARY KEY ("TableNameID")
);
CREATE TABLE "Changes"(
	"ChangeID" int NOT NULL ,
	"RequestID" int NOT NULL,
	"ChangeReasonID" int NOT NULL,
	"RevDate" TIMESTAMP NULL,
    PRIMARY KEY("ChangeID"),
    CONSTRAINT "FK_ChangeReason_Changes" FOREIGN KEY ("ChangeReasonID")
        REFERENCES "ChangeReasons" ("ChangeReasonID")
        ON DELETE NO ACTION ON UPDATE NO ACTION
);

CREATE TABLE "ChangeDetails"(
	"ChangeDetailID" int NOT NULL ,
	"ChangeID" int NOT NULL,
	"ChangeAttributeStateID" int NOT NULL,
	"TableNameID" int NOT NULL,
	"PrimaryKeyColumnName" varchar(255) NULL,
	"PrimaryKeyBefore" int NULL,
	"PrimaryKeyAfter" int NULL,
	"ColumnName" varchar(255) NULL,
	"ColumnValueBefore" varchar(1000) NULL,
	"ColumnValueAfter" varchar(1000) NULL,
    PRIMARY KEY ("ChangeDetailID"),
    CONSTRAINT "FK_Changes_ChangeDetails" FOREIGN KEY ("ChangeID")
        REFERENCES "Changes" ("ChangeID")
        ON DELETE NO ACTION ON UPDATE NO ACTION,
	CONSTRAINT "FK_ChangeAttributeStates_ChangeDetails" FOREIGN KEY ("ChangeAttributeStateID")
		REFERENCES "ChangeAttributeStates" ("ChangeAttributeStateID")
		ON DELETE NO ACTION ON UPDATE NO ACTION,
	CONSTRAINT "FK_ChangeTableNames_ChangeDetails" FOREIGN KEY ("TableNameID")
		REFERENCES "ChangeTableNames" ("TableNameID")
		ON DELETE NO ACTION ON UPDATE NO ACTION    
    
);

CREATE TABLE Version(
	VersionDate date NOT NULL
);

CREATE TABLE "Year" (
    "YearID" INT NOT NULL,
    PRIMARY KEY ("YearID")
);

CREATE TABLE VCdbChanges(
	VersionDate TIMESTAMP NOT NULL,
	TableName varchar(30) NOT NULL,
	ID int NOT NULL,
	Action varchar(1) NOT NULL
) 
;

CREATE TABLE Attachment(

	AttachmentID int  NOT NULL ,

	AttachmentTypeID int NOT NULL,

	AttachmentFileName varchar(50) NOT NULL,

	AttachmentURL varchar(100) NOT NULL,

	AttachmentDescription varchar(50) NOT NULL,
    Primary key (AttachmentID)
	)

;

CREATE TABLE AttachmentType(

	AttachmentTypeID int  NOT NULL ,

	AttachmentTypeName varchar(20) NOT NULL,
    Primary key(AttachmentTypeID)
	)

;

CREATE TABLE EnglishPhrase(

	EnglishPhraseID int  NOT NULL ,

	EnglishPhrase varchar(100) NOT NULL,
    Primary key(EnglishPhraseID)
	)

;

CREATE TABLE Language(

	LanguageID int NOT NULL ,

	LanguageName varchar(20) NOT NULL,

	DialectName varchar(20) NULL,
    
    Primary key(LanguageID)
	)

;

CREATE TABLE LanguageTranslation(

	LanguageTranslationID int  NOT NULL ,

	EnglishPhraseID int NOT NULL,

	LanguageID int NOT NULL,

	Translation varchar(150) NOT NULL,
    
    Primary KEY (LanguageTranslationID)
	)

;

CREATE TABLE LanguageTranslationAttachment(

	LanguageTranslationAttachmentID int NOT NULL ,

	LanguageTranslationID int NOT NULL,

	AttachmentID int NOT NULL,
    
    Primary key(LanguageTranslationAttachmentID)
	
	);








