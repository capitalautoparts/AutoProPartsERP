

CREATE TABLE "BrakeABS" (
    "BrakeABSID" INT NOT NULL,
    "BrakeABSName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("BrakeABSID")
);
CREATE TABLE "BrakeType" (
    "BrakeTypeID" INT NOT NULL,
    "BrakeTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("BrakeTypeID")
);
CREATE TABLE "BrakeSystem" (
    "BrakeSystemID" INT NOT NULL,
    "BrakeSystemName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("BrakeSystemID")
);

CREATE TABLE "Aspiration" (
    "AspirationID" INT NOT NULL,
    "AspirationName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("AspirationID")
);

CREATE TABLE "BedType" (
    "BedTypeID" INT NOT NULL,
    "BedTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("BedTypeID")
);


CREATE TABLE "BodyType" (
    "BodyTypeID" INT NOT NULL,
    "BodyTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("BodyTypeID")
);




CREATE TABLE "ElecControlled" (
    "ElecControlledID" INT NOT NULL,
    "ElecControlled" VARCHAR(10) NOT NULL,
    PRIMARY KEY ("ElecControlledID")
);


CREATE TABLE "FuelDeliverySubType" (
    "FuelDeliverySubTypeID" INT NOT NULL,
    "FuelDeliverySubTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("FuelDeliverySubTypeID")
);
CREATE TABLE "FuelDeliveryType" (
    "FuelDeliveryTypeID" INT NOT NULL,
    "FuelDeliveryTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("FuelDeliveryTypeID")
);
CREATE TABLE "FuelSystemControlType" (
    "FuelSystemControlTypeID" INT NOT NULL,
    "FuelSystemControlTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("FuelSystemControlTypeID")
);

CREATE TABLE "FuelType" (
    "FuelTypeID" INT NOT NULL,
    "FuelTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("FuelTypeID")
);
CREATE TABLE "IgnitionSystemType" (
    "IgnitionSystemTypeID" INT NOT NULL,
    "IgnitionSystemTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("IgnitionSystemTypeID")
);


CREATE TABLE "Region" (
    "RegionID" INT NOT NULL,
    "ParentID" INT DEFAULT NULL,
    "RegionAbbr" VARCHAR(3) DEFAULT NULL,
    "RegionName" VARCHAR(250) DEFAULT NULL,
    PRIMARY KEY ("RegionID")
    
);

CREATE TABLE "SpringType" (
    "SpringTypeID" INT NOT NULL,
    "SpringTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("SpringTypeID")
);


CREATE TABLE "SteeringType" (
    "SteeringTypeID" INT NOT NULL,
    "SteeringTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("SteeringTypeID")
);

CREATE TABLE "TransmissionControlType" (
    "TransmissionControlTypeID" INT NOT NULL,
    "TransmissionControlTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("TransmissionControlTypeID")
);


CREATE TABLE "TransmissionType" (
    "TransmissionTypeID" INT NOT NULL,
    "TransmissionTypeName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("TransmissionTypeID")
);



CREATE TABLE Version(
	VersionDate date NOT NULL
);



CREATE TABLE "SteeringSystem" (
    "SteeringSystemID" INT NOT NULL,
    "SteeringSystemName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("SteeringSystemID")
);



CREATE TABLE "VehicleTypeGroup" (
    "VehicleTypeGroupID" INT NOT NULL,
    "VehicleTypeGroupName" VARCHAR(250) NOT NULL,
    PRIMARY KEY ("VehicleTypeGroupID")
);



CREATE TABLE "VehicleType" (
    "VehicleTypeID" INT NOT NULL,
    "VehicleTypeName" VARCHAR(250) NOT NULL,
	"VehicleTypeGroupID" INT NULL,
    PRIMARY KEY ("VehicleTypeID")
);


CREATE TABLE "ChangeAttributeStates"(
	"ChangeAttributeStateID" int NOT NULL ,
	"ChangeAttributeState" VARCHAR(255) NOT NULL,
PRIMARY KEY("ChangeAttributeStateID")
);

CREATE TABLE "ChangeReasons"(
	"ChangeReasonID" int NOT NULL,
	"ChangeReason" VARCHAR(255) NOT NULL,
    PRIMARY KEY ("ChangeReasonID")
);

CREATE TABLE "ChangeTableNames"(
	"TableNameID" int NOT NULL,
	"TableName" VARCHAR(255) NOT NULL,
	"TableDescription" VARCHAR(1000) NULL,
    PRIMARY KEY ("TableNameID")
);
CREATE TABLE "Changes"(
	"ChangeID" int NOT NULL ,
	"RequestID" int NOT NULL,
	"ChangeReasonID" int NOT NULL,
	"RevDate" TIMESTAMP NULL,
    PRIMARY KEY("ChangeID")
);

CREATE TABLE "ChangeDetails"(
	"ChangeDetailID" int NOT NULL ,
	"ChangeID" int NOT NULL,
	"ChangeAttributeStateID" int NOT NULL,
	"TableNameID" int NOT NULL,
	"PrimaryKeyColumnName" VARCHAR(255) NULL,
	"PrimaryKeyBefore" int NULL,
	"PrimaryKeyAfter" int NULL,
	"ColumnName" VARCHAR(255) NULL,
	"ColumnValueBefore" VARCHAR(1000) NULL,
	"ColumnValueAfter" VARCHAR(1000) NULL,
    PRIMARY KEY ("ChangeDetailID") 
    
);
  

  CREATE TABLE VCdbChanges(
	VersionDate TIMESTAMP NULL,
	TableName VARCHAR(30) NULL,
	ID int NULL,
	Action char(1) NULL
) ;



