  -- ----------------------------------------------------------------------------
-- Table PCADB.ChangeLogTables
-- ----------------------------------------------------------------------------

CREATE TABLE `ChangeAttributeStates`(
	`ChangeAttributeStateID` int NOT NULL ,
	`ChangeAttributeState` varchar(255) NOT NULL,
PRIMARY KEY(`ChangeAttributeStateID`)
);

CREATE TABLE `ChangeReasons`(
	`ChangeReasonID` int NOT NULL,
	`ChangeReason` varchar(255) NOT NULL,
    PRIMARY KEY (`ChangeReasonID`)
);

CREATE TABLE `ChangeTableNames`(
	`TableNameID` int NOT NULL,
	`TableName` varchar(255) NOT NULL,
	`TableDescription` varchar(1000) NULL,
    PRIMARY KEY (`TableNameID`)
);
CREATE TABLE `Changes`(
	`ChangeID` int NOT NULL AUTO_INCREMENT,
	`RequestID` int NOT NULL,
	`ChangeReasonID` int NOT NULL,
	`RevDate` datetime NULL,
    PRIMARY KEY(`ChangeID`),
    KEY `IDX_Changes_ChangeReason_ChangeReasonID` (`ChangeReasonID`),
    CONSTRAINT `FK_ChangeReason_Changes` FOREIGN KEY (`ChangeReasonID`)
        REFERENCES `changereasons` (`ChangeReasonID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION
);

CREATE TABLE `ChangeDetails`(
	`ChangeDetailID` int NOT NULL AUTO_INCREMENT,
	`ChangeID` int NOT NULL,
	`ChangeAttributeStateID` int NOT NULL,
	`TableNameID` int NOT NULL,
	`PrimaryKeyColumnName` varchar(255) NULL,
	`PrimaryKeyBefore` int NULL,
	`PrimaryKeyAfter` int NULL,
	`ColumnName` varchar(255) NULL,
	`ColumnValueBefore` varchar(1000) NULL,
	`ColumnValueAfter` varchar(1000) NULL,
    PRIMARY KEY (`ChangeDetailID`),
	KEY `IDX_ChangeDetails_Changes_ChangeID` (`ChangeID`),
    KEY `IDX_ChangeDetails_ChangeAttributeStates_ChangeAttributeStateID` (`ChangeAttributeStateID`),
    KEY `IDX_ChangeDetails_ChangeTableNames_TableNameID` (`TableNameID`),
    CONSTRAINT `FK_Changes_ChangeDetails` FOREIGN KEY (`ChangeID`)
        REFERENCES `changes` (`ChangeID`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
	CONSTRAINT `FK_ChangeAttributeStates_ChangeDetails` FOREIGN KEY (`ChangeAttributeStateID`)
		REFERENCES `changeattributestates` (`ChangeAttributeStateID`)
		ON DELETE NO ACTION ON UPDATE NO ACTION,
	CONSTRAINT `FK_ChangeTableNames_ChangeDetails` FOREIGN KEY (`TableNameID`)
		REFERENCES `changetablenames` (`TableNameID`)
		ON DELETE NO ACTION ON UPDATE NO ACTION    
    
);
  
-- ----------------------------------------------------------------------------
-- Table PCADB.Alias
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `Alias` (
  `AliasID` INT NOT NULL,
  `AliasName` varchar(500) NOT NULL,
  PRIMARY KEY (`AliasID`));

-- ----------------------------------------------------------------------------
-- Table PCADB.Use
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `Use` (
  `UseID` INT NOT NULL,
  `UseDescription` varchar(500) NOT NULL,
  PRIMARY KEY (`UseId`));
-- ----------------------------------------------------------------------------
-- Table PCADB.Subcategories
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `Subcategories` (
  `SubCategoryID` INT NOT NULL,
  `SubCategoryName` varchar(500) NOT NULL,
  PRIMARY KEY (`SubCategoryID`));

-- ----------------------------------------------------------------------------
-- Table PCADB.Positions
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `Positions` (
  `PositionID` INT NOT NULL,
  `Position` varchar(500) NOT NULL,
  PRIMARY KEY (`PositionID`));

-- ----------------------------------------------------------------------------
-- Table PCADB.Categories
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `Categories` (
  `CategoryID` INT NOT NULL,
  `CategoryName` varchar(500) NOT NULL,
  PRIMARY KEY (`CategoryID`));
SET FOREIGN_KEY_CHECKS = 1;

	-- ----------------------------------------------------------------------------
-- Table PCADB.PartsDescription
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `PartsDescription` (
  `PartsDescriptionID` INT NOT NULL,
  `PartsDescription` varchar(1000) NOT NULL,
  PRIMARY KEY (`PartsDescriptionID`));

  -- ----------------------------------------------------------------------------
-- Table PCADB.Parts
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `Parts` (
  `PartTerminologyID` INT NOT NULL,
  `PartTerminologyName` varchar(500) NOT NULL,
  `PartsDescriptionID` INT NULL,
  `RevDate` DATE NULL,
  PRIMARY KEY (`PartTerminologyID`),
  CONSTRAINT `FK_dbo.Parts_dbo.PartsDescription_PartsDescriptionId`
    FOREIGN KEY (`PartsDescriptionID`)
    REFERENCES `PartsDescription` (`PartsDescriptionID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);

-- ----------------------------------------------------------------------------
-- Table PCADB.PartsToAlias
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `PartsToAlias` (
  `PartTerminologyID` INT NOT NULL,
  `AliasID` INT NOT NULL
  );

	
	
-- ----------------------------------------------------------------------------
-- Table PCADB.PartsRelationship
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `PartsRelationship` (
  `PartTerminologyID` INT NOT NULL,
  `RelatedPartTerminologyID` INT NOT NULL
  );


-- ----------------------------------------------------------------------------
-- Table PCADB.PartsToUse
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `PartsToUse` (
  `PartTerminologyID` INT NOT NULL,
  `UseID` INT NOT NULL
  );
	
	-- ----------------------------------------------------------------------------
-- Table PCADB.CodeMaster
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `CodeMaster` (
  `CodeMasterID` INT NOT NULL,
  `PartTerminologyID` INT NOT NULL,
  `CategoryID` INT NOT NULL,
  `SubCategoryID` INT NOT NULL,
  `PositionID` INT NOT NULL,
  `RevDate` date null,
  PRIMARY KEY (`CodeMasterID`),
  CONSTRAINT `FK_dbo.CodeMaster_dbo.Positions_PositionID`
    FOREIGN KEY (`PositionID`)
    REFERENCES `Positions` (`PositionID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_dbo.CodeMaster_dbo.Categories_CategoryID`
    FOREIGN KEY (`CategoryID`)
    REFERENCES `Categories` (`CategoryID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK_dbo.CodeMaster_dbo.Subcategories_SubCategoryID`
    FOREIGN KEY (`SubCategoryID`)
    REFERENCES `Subcategories` (`SubCategoryID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
	

Create Table Version(
VersionDate Date NULL
);

CREATE TABLE PIESCode(
	`PIESCodeId` int NOT NULL,
	`CodeValue` varchar(500) NOT NULL,
	`CodeFormat` varchar(500) NOT NULL,
	`FieldFormat` varchar(500)  NULL,
	`CodeDescription` varchar(500) NOT NULL,
	`Source` varchar(500) NULL,
 CONSTRAINT `PK_dbo.PIESCode` PRIMARY KEY 
(
	`PIESCodeId` ASC
) 
);
 
CREATE TABLE PIESExpiCode(
	`PIESExpiCodeId` int NOT NULL,
	`ExpiCode` varchar(100) NOT NULL,
	`ExpiCodeDescription` varchar(500) NOT NULL,
	`PIESExpiGroupId` int NOT NULL,
 CONSTRAINT `PK_dbo.PIESExpiCode` PRIMARY KEY 
(
	`PIESExpiCodeId` ASC
) 
);

 
CREATE TABLE PIESExpiGroup(
	`PIESExpiGroupId` int NOT NULL,
	`ExpiGroupCode` varchar(500) NOT NULL,
	`ExpiGroupDescription` varchar(500) NOT NULL,
 CONSTRAINT `PK_dbo.PIESExpiGroup` PRIMARY KEY 
(
	`PIESExpiGroupId` ASC
) 
);

 
CREATE TABLE PIESField(
	`PIESFieldId` int NOT NULL,
	`FieldName` varchar(500) NOT NULL,
	`ReferenceFieldNumber` varchar(500) NOT NULL,
	`PIESSegmentId` int NOT NULL,
 CONSTRAINT `PK_dbo.PIESField` PRIMARY KEY 
(
	`PIESFieldId` ASC
) 
);

 
CREATE TABLE PIESReferenceFieldCode(
	`PIESReferenceFieldCodeId` int NOT NULL,
	`PIESFieldId` int NOT NULL,
	`PIESCodeId` int NOT NULL,
	`PIESExpiCodeId` int NULL,
	`ReferenceNotes` varchar(2000) NULL,
 CONSTRAINT `PK_dbo.PIESReferenceFieldCode` PRIMARY KEY 
(
	`PIESReferenceFieldCodeId` ASC
) 
);

 
CREATE TABLE PIESSegment(
	`PIESSegmentId` int NOT NULL,
	`SegmentAbb` varchar(100) NOT NULL,
	`SegmentName` varchar(100) NOT NULL,
	`SegmentDescription` varchar(250) NOT NULL,
 CONSTRAINT `PK_dbo.PIESSegment` PRIMARY KEY 
(
	`PIESSegmentId` ASC
) 
);


CREATE TABLE PartsSupersession(
	OldPartTerminologyID int NOT NULL,
	OldPartTerminologyName varchar(200) NOT NULL,
	NewPartTerminologyID int NOT NULL,
	NewPartTerminologyName varchar(200) NOT NULL,
	RevDate date NULL
 );

 
ALTER TABLE `PIESExpiCode`  ADD  CONSTRAINT `FK_dbo.PIESExpiCode_dbo.PIESExpiGroup_PIESExpiGroupId` FOREIGN KEY(`PIESExpiGroupId`)
REFERENCES `PIESExpiGroup` (`PIESExpiGroupId`)
ON DELETE CASCADE;



ALTER TABLE `PIESField`  ADD  CONSTRAINT `FK_dbo.PIESField_dbo.PIESSegment_PIESSegmentId` FOREIGN KEY(`PIESSegmentId`)
REFERENCES `PIESSegment` (`PIESSegmentId`)
ON DELETE CASCADE;


ALTER TABLE `PIESReferenceFieldCode`  ADD  CONSTRAINT `FK_dbo.PIESReferenceFieldCode_dbo.PIESCode_PIESCodeId` FOREIGN KEY(`PIESCodeId`)
REFERENCES `PIESCode` (`PIESCodeId`)
ON DELETE CASCADE;


ALTER TABLE `PIESReferenceFieldCode`  ADD  CONSTRAINT `FK_dbo.PIESReferenceFieldCode_dbo.PIESExpiCode_PIESExpiCodeId` FOREIGN KEY(`PIESExpiCodeId`)
REFERENCES `PIESExpiCode` (`PIESExpiCodeId`)
ON DELETE CASCADE;


ALTER TABLE `PIESReferenceFieldCode`  ADD  CONSTRAINT `FK_dbo.PIESReferenceFieldCode_dbo.PIESField_PIESFieldId` FOREIGN KEY(`PIESFieldId`)
REFERENCES `PIESField` (`PIESFieldId`)
ON DELETE CASCADE;


-- ----------------------------------------------------------------------------
-- Table ACESCodedValues
-- ----------------------------------------------------------------------------
CREATE TABLE ACESCodedValues(
	`Element` varchar(255) NULL,
	`Attribute` varchar(255) NULL,
	`CodedValue` varchar(255) NULL,
	`CodeDescription` varchar(255) NULL
);