-- ----------------------------------------------------------------------------
-- Table PCADB.MetaData
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `MetaData` (
  `MetaID` INT NOT NULL,
  `MetaName` VARCHAR(80) NULL,
  `MetaDescr` VARCHAR(512) NULL,
  `MetaFormat` VARCHAR(10) NULL,
  `DataType` VARCHAR(50) NULL,
  `MinLength` INT NULL,
  `MaxLength` INT NULL,
  PRIMARY KEY (`MetaID`)
);

-- ----------------------------------------------------------------------------
-- Table PCADB.PartAttributes
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `PartAttributes` (
  `PAID` INT NOT NULL,
  `PAName` VARCHAR(80) NULL,
  `PADescr` VARCHAR(512) NULL,
  PRIMARY KEY (`PAID`)
);

-- ----------------------------------------------------------------------------
-- Table PCADB.Style
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `Style` (
  `StyleID` INT NOT NULL,
  `StyleName` VARCHAR(225) NULL,
  PRIMARY KEY (`StyleID`)
);

-- ----------------------------------------------------------------------------
-- Table PCADB.MeasurementGroup
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `MeasurementGroup` (
  `MeasurementGroupID` INT NOT NULL,
  `MeasurementGroupName` VARCHAR(80) NULL,
  PRIMARY KEY (`MeasurementGroupID`)
);

-- ----------------------------------------------------------------------------
-- Table PCADB.MetaUOMCodes
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `MetaUOMCodes` (
  `MetaUOMID` INT NOT NULL,
  `UOMCode` VARCHAR(10) NULL,
  `UOMDescription` VARCHAR(512) NULL,
  `UOMLabel` VARCHAR(10) NULL,
  `MeasurementGroupID` INT NOT NULL,
  PRIMARY KEY (`MetaUOMID`),
  FOREIGN KEY (`MeasurementGroupID`) REFERENCES `MeasurementGroup` (`MeasurementGroupID`)
);

-- ----------------------------------------------------------------------------
-- Table PCADB.PartAttributeAssignment
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `PartAttributeAssignment` (
  `PAPTID` INT NOT NULL,
  `PartTerminologyID` INT NOT NULL,
  `PAID` INT NOT NULL,
  `MetaID` INT NOT NULL,
  PRIMARY KEY (`PAPTID`),
  FOREIGN KEY (`PAID`) REFERENCES `PartAttributes` (`PAID`),
  FOREIGN KEY (`MetaID`) REFERENCES `MetaData` (`MetaID`)
);

-- ----------------------------------------------------------------------------
-- Table PCADB.MetaUOMCodeAssignment
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `MetaUOMCodeAssignment` (
  `MetaUOMCodeAssignmentID` INT NOT NULL,
  `PAPTID` INT NOT NULL,
  `MetaUOMID` INT NOT NULL,
  PRIMARY KEY (`MetaUOMCodeAssignmentID`),
  FOREIGN KEY (`PAPTID`) REFERENCES `PartAttributeAssignment` (`PAPTID`),
  FOREIGN KEY (`MetaUOMID`) REFERENCES `MetaUOMCodes` (`MetaUOMID`)
);

-- ----------------------------------------------------------------------------
-- Table PCADB.PartAttributeStyle
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `PartAttributeStyle` (
  `StyleID` INT NOT NULL,
  `PAPTID` INT NOT NULL,
  FOREIGN KEY (`PAPTID`) REFERENCES `PartAttributeAssignment` (`PAPTID`)
);

-- ----------------------------------------------------------------------------
-- Table PCADB.PartTypeStyle
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `PartTypeStyle` (
  `StyleID` INT NOT NULL,
  `PartTerminologyID` INT NOT NULL,
  FOREIGN KEY (`StyleID`) REFERENCES `Style` (`StyleID`)
);

-- ----------------------------------------------------------------------------
-- Table PCADB.ValidValues
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `ValidValues` (
  `ValidValueID` INT NOT NULL,
  `ValidValue` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`ValidValueID`)
);

-- ----------------------------------------------------------------------------
-- Table PCADB.ValidValueAssignment
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `ValidValueAssignmenmeasurementgroupmeasurementgroupt` (
  `ValidValueAssignmentID` INT NOT NULL,
  `PAPTID` INT NOT NULL,
  `ValidValueID` INT NOT NULL,
  PRIMARY KEY (`ValidValueAssignmentID`),
  FOREIGN KEY (`PAPTID`) REFERENCES `PartAttributeAssignment` (`PAPTID`),
  FOREIGN KEY (`ValidValueID`) REFERENCES `ValidValues` (`ValidValueID`)
);

-- ----------------------------------------------------------------------------
-- Table PCADB.Version
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `Version` (
  `PAdbVersion` VARCHAR(10) NULL,
  `PAdbPublication` DATE NULL,
  `PCdbPublication` DATE NULL
);
