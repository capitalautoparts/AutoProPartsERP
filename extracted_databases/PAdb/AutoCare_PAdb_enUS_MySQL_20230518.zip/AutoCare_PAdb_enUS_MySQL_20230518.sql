-- MySQL dump 10.13  Distrib 5.7.16, for Win64 (x86_64)
--
-- Host: localhost    Database: mysql_padb
-- ------------------------------------------------------
-- Server version	5.7.28-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `MeasurementGroup`
--

DROP TABLE IF EXISTS `MeasurementGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MeasurementGroup` (
  `MeasurementGroupID` int(11) NOT NULL,
  `MeasurementGroupName` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`MeasurementGroupID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MeasurementGroup`
--

LOCK TABLES `MeasurementGroup` WRITE;
/*!40000 ALTER TABLE `MeasurementGroup` DISABLE KEYS */;
INSERT INTO `MeasurementGroup` VALUES (1,'Linear Measurements'),(5,'Performance'),(6,'Time'),(7,'Temperature and Energy'),(8,'Electrical');
/*!40000 ALTER TABLE `MeasurementGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MetaData`
--

DROP TABLE IF EXISTS `MetaData`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MetaData` (
  `MetaID` int(11) NOT NULL,
  `MetaName` varchar(80) DEFAULT NULL,
  `MetaDescr` varchar(512) DEFAULT NULL,
  `MetaFormat` varchar(10) DEFAULT NULL,
  `DataType` varchar(50) DEFAULT NULL,
  `MinLength` int(11) DEFAULT NULL,
  `MaxLength` int(11) DEFAULT NULL,
  PRIMARY KEY (`MetaID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MetaData`
--

LOCK TABLES `MetaData` WRITE;
/*!40000 ALTER TABLE `MetaData` DISABLE KEYS */;
INSERT INTO `MetaData` VALUES (74,'Alphanumeric of 255','Alphanumeric of 255','AN1/255','Alphanumeric',1,255),(88,'Numeric measurement floating decimal','','R1/10','Numeric measurement floating decimal',1,10),(89,'Alphanumeric of 80','Alphanumeric of 80','ID80','Alphanumeric',1,80),(163,'Numeric measurement no decimal','','N0-1/10','Numeric measurement no decimal',1,10),(178,'Numeric quantity, whole number of 80','Numeric quantity, whole number of 80.','N1/80','Numeric quantity, whole number',1,80);
/*!40000 ALTER TABLE `MetaData` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MetaUOMCodeAssignment`
--

DROP TABLE IF EXISTS `MetaUOMCodeAssignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MetaUOMCodeAssignment` (
  `MetaUOMCodeAssignmentID` int(11) NOT NULL,
  `PAPTID` int(11) NOT NULL,
  `MetaUOMID` int(11) NOT NULL,
  PRIMARY KEY (`MetaUOMCodeAssignmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MetaUOMCodeAssignment`
--

LOCK TABLES `MetaUOMCodeAssignment` WRITE;
/*!40000 ALTER TABLE `MetaUOMCodeAssignment` DISABLE KEYS */;
INSERT INTO `MetaUOMCodeAssignment` VALUES (1120,22001,4),(1121,22001,1),(1788,22056,4),(1789,22056,1),(3750,22930,4),(3751,22930,1),(3752,22933,4),(3753,22933,1),(3754,22935,82),(3755,22938,4),(3756,22938,1),(8972,25011,4),(8973,25011,1),(8974,25012,4),(8975,25012,1),(8976,25013,75),(8977,25013,76),(12320,27748,4),(12321,27748,1),(12322,27753,4),(12323,27753,1),(12324,27754,4),(12325,27754,1),(50713,76663,4),(50714,76663,1),(50715,76667,4),(50716,76667,1),(66862,121790,4),(66863,121790,1),(78410,156475,70),(78413,156477,67),(78414,156479,81),(78415,156480,78),(78416,156481,81),(78417,156482,75),(78418,156482,76),(78421,156484,67),(78422,156492,1),(78423,156492,4),(78424,156493,1),(78425,156493,4),(78426,156494,70),(78429,156496,67),(78430,156497,67),(78431,156499,81),(78432,156500,78),(78433,156501,75),(78434,156501,76),(78437,156505,81),(78438,156506,78),(78439,156507,75),(78440,156507,76),(78441,156513,1),(78442,156513,4),(78443,156514,1),(78444,156514,4),(78445,156515,1),(78446,156515,4),(78447,156516,1),(78448,156516,4),(78531,156624,45),(78532,156624,47),(78535,156626,45),(78536,156626,47),(78537,156627,45),(78538,156627,47),(78539,156628,45),(78540,156628,47),(79044,157418,78),(94501,184681,1),(94502,184681,4),(94503,184682,1),(94504,184682,4),(94505,184683,1),(94506,184683,4),(94507,184684,1),(94508,184684,4),(94992,185220,1),(94993,185220,4),(95039,185363,1),(95040,185363,4),(95041,185364,1),(95042,185364,4),(95134,185462,1),(95135,185462,4),(97648,188575,1),(97649,188575,4),(97821,188877,117),(99785,191484,45),(99786,191484,46),(99787,191484,47);
/*!40000 ALTER TABLE `MetaUOMCodeAssignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MetaUOMCodes`
--

DROP TABLE IF EXISTS `MetaUOMCodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MetaUOMCodes` (
  `MetaUOMID` int(11) NOT NULL,
  `UOMCode` varchar(10) DEFAULT NULL,
  `UOMDescription` varchar(512) DEFAULT NULL,
  `UOMLabel` varchar(10) DEFAULT NULL,
  `MeasurementGroupID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MetaUOMCodes`
--

LOCK TABLES `MetaUOMCodes` WRITE;
/*!40000 ALTER TABLE `MetaUOMCodes` DISABLE KEYS */;
INSERT INTO `MetaUOMCodes` VALUES (1,'MM','Millimeter','mm',1),(4,'IN','Inch','in',1),(45,'LU','Lumens','lm',5),(46,'LX','Lux','lx',5),(47,'CP','Candlepower','C.P.',5),(67,'HR','Hours','h',6),(70,'KV','Degrees Kelvin','Deg. K',7),(75,'2G','Volts AC','VAC',8),(76,'2H','Volts DC','VDC',8),(78,'99','Watts','W',8),(81,'68','Ampere','A',8),(82,'82','Ohm','Ohms',8),(117,'4S','Pascal','Pa',5);
/*!40000 ALTER TABLE `MetaUOMCodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartAttributeAssignment`
--

DROP TABLE IF EXISTS `PartAttributeAssignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PartAttributeAssignment` (
  `PAPTID` int(11) NOT NULL,
  `PartTerminologyID` int(11) NOT NULL,
  `PAID` int(11) NOT NULL,
  `MetaID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartAttributeAssignment`
--

LOCK TABLES `PartAttributeAssignment` WRITE;
/*!40000 ALTER TABLE `PartAttributeAssignment` DISABLE KEYS */;
INSERT INTO `PartAttributeAssignment` VALUES (22001,1684,79,88),(22002,1684,30,89),(22056,1684,106,88),(22059,1684,34,89),(22060,1684,1217,89),(22930,7212,549,88),(22931,7212,550,178),(22933,7212,552,88),(22934,7212,553,178),(22935,7212,1132,163),(22938,7212,557,88),(24629,7212,1156,74),(24633,7212,1159,89),(24938,11701,1268,89),(25010,11718,1272,74),(25011,11718,111,88),(25012,11718,14,88),(25013,11718,123,88),(27746,17220,1681,89),(27747,17220,17,74),(27748,17220,14,88),(27749,17220,2705,89),(27751,17220,1671,89),(27752,17220,33,74),(27753,17220,19,88),(27754,17220,24,88),(27755,17220,1672,89),(76663,14269,14,88),(76664,14269,10,74),(76666,14269,4748,178),(76667,14269,2393,88),(76668,14269,63,89),(121790,7212,556,88),(126122,1684,3390,89),(136527,1684,4,89),(154735,7212,605,89),(156238,1684,9059,89),(156257,7212,3858,89),(156371,1684,55,74),(156460,1684,170,89),(156461,1684,9076,89),(156467,1684,3596,74),(156473,1684,9066,89),(156474,11718,1268,89),(156475,11718,9078,163),(156477,11718,9080,163),(156478,11718,9081,74),(156479,11718,9082,88),(156480,11718,9083,88),(156481,11718,89,88),(156482,11718,9084,88),(156484,11718,2786,163),(156485,11718,9085,74),(156486,11718,1269,89),(156487,11718,1284,74),(156488,11718,9086,89),(156489,11718,1822,74),(156490,11718,9087,89),(156491,11718,5950,89),(156492,11718,31,88),(156493,11718,24,88),(156494,11701,9078,163),(156496,11701,2786,163),(156497,11701,9080,163),(156498,11701,9081,74),(156499,11701,9082,88),(156500,11701,9083,88),(156501,11701,9084,88),(156503,11701,1269,89),(156504,11701,9085,74),(156505,11701,89,88),(156506,11701,975,88),(156507,11701,123,88),(156508,11701,1284,74),(156509,11701,9086,89),(156510,11701,1822,74),(156511,11701,9087,89),(156512,11701,5950,89),(156513,11701,31,88),(156514,11701,24,88),(156515,11701,14,88),(156516,11701,111,88),(156517,11701,1272,74),(156624,11718,8363,88),(156626,11701,8363,88),(156627,11718,9079,88),(156628,11701,9079,88),(157418,11718,975,88),(157654,7212,555,89),(158751,7212,548,89),(158983,1684,9286,89),(160596,1684,3,89),(160629,14269,1318,89),(160633,14269,9294,89),(164254,7212,551,74),(164303,7212,1155,74),(164501,7212,547,89),(165998,14269,5217,89),(167086,14269,17,74),(169222,17220,26,89),(172419,7212,9383,89),(172687,1684,4543,89),(172689,1684,9407,89),(183225,1684,8701,74),(183226,1684,7673,74),(183232,1684,9423,89),(183233,1684,9422,89),(183234,1684,9421,74),(184681,1684,9433,88),(184682,1684,9434,88),(184683,1684,9435,88),(184684,1684,9436,88),(184693,1684,7321,89),(185167,11701,1270,74),(185219,7212,9459,89),(185220,7212,6648,88),(185363,1684,9478,88),(185364,1684,9479,88),(185462,7212,9506,88),(185494,7212,9507,89),(185987,7212,9608,89),(187738,11718,9717,178),(188503,7212,9746,89),(188504,7212,9745,89),(188505,7212,1917,89),(188575,7212,9748,88),(188877,7212,9793,88),(188987,7212,604,89),(189274,7212,9805,89),(191484,11701,9995,163),(193704,11701,1271,89),(193973,57237,10148,74),(193974,57237,10147,74),(193975,17220,10,74);
/*!40000 ALTER TABLE `PartAttributeAssignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartAttributeStyle`
--

DROP TABLE IF EXISTS `PartAttributeStyle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PartAttributeStyle` (
  `StyleID` int(11) DEFAULT NULL,
  `PaptID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartAttributeStyle`
--

LOCK TABLES `PartAttributeStyle` WRITE;
/*!40000 ALTER TABLE `PartAttributeStyle` DISABLE KEYS */;
/*!40000 ALTER TABLE `PartAttributeStyle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartAttributes`
--

DROP TABLE IF EXISTS `PartAttributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PartAttributes` (
  `PAID` int(11) NOT NULL,
  `PAName` varchar(80) DEFAULT NULL,
  `PADescr` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`PAID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartAttributes`
--

LOCK TABLES `PartAttributes` WRITE;
/*!40000 ALTER TABLE `PartAttributes` DISABLE KEYS */;
INSERT INTO `PartAttributes` VALUES (3,'Friction Material Composition','Describes The Friction Material Of The Brake Pad'),(4,'Friction Material Attachment','Describes How Friction Material Is Attached To The Pad Or Shoe'),(10,'Material','Describes Material'),(14,'Length','Describes Measurement'),(17,'Color','Describes Color'),(19,'Thickness','Describes Measurement'),(24,'Width','Describes Measurement'),(26,'Type','Describes Type'),(30,'Mounting Hardware Included','Describes If Any Installation Hardware Is Included'),(31,'Height','Describes Measurement'),(33,'Shape','Describe Shape'),(34,'Pad Shims Included','Describes If Shims Are Included'),(55,'FMSI Number','Describes The Friction Materials Standard Institute (FMSI) Number.'),(63,'Waterproof','Describes If Product Is Impervious To Water'),(79,'Inner Pad Friction Material Thickness','Describes The Inner Pad Friction Material Thickness.'),(89,'Amperage Rating','Describes Maximum Current Draw Measurement Of A Device'),(106,'Outer Pad Friction Material Thickness','Describes The Outer Pad Friction Material Thickness.'),(111,'Diameter','Describes Measurement'),(123,'Voltage','Describes Voltage Measurement'),(170,'Slotted','Important for wet performance and resistance to pad glazing'),(547,'Center Electrode Core Material','Describes The Material Of The Center Electrode Core'),(548,'Center Electrode Tip Material','Describes The Material Of The Center Electrode Tip'),(549,'Pre-Gap Size','Describes The Pre-Gap Measurement From The Factory'),(550,'Ground Electrode Quantity','Describes Quantity'),(551,'Hex Size','Describes Measurement Of Hex Portion'),(552,'Insulator Height','Describes the height of the insulator of the spark plug as measured from the seat to the terminal'),(553,'Manufacturer Heat Range','Describes Heat Range Number'),(555,'Seat Type','Describes Seat Type'),(556,'Reach','Describes Measurement of length of the spark plug metal body from seat portion to the end of spark plug threads also can be described as the cylinder head thickness. Can be expressed as both inches and or millimeters.'),(557,'Thread Diameter','Describes The Outer Diameter Of The Threaded Portion Of The Fastener Measured In Metric or Standard. Also Known As Major Diameter.'),(604,'Insulator Material','Describes Material'),(605,'Resistor Type','Is the product radio frequency resistant'),(975,'Wattage','Describes Wattage Measurement'),(1132,'Resistance','Describes Measurement'),(1155,'Ground Electrode Tip Design','Describes the configuration of the ground electrode tip'),(1156,'Ground Configuration','Describes the configuration of the ground electrode or grounding method of the spark plug but not the quantity of ground electrodes as this is a separate category'),(1159,'Ground Electrode Core Material','Describes The Material Of The Ground Electrode Core Material'),(1217,'Pad Wear Sensor Included','Describes If Has Pad Wear Sensor Included'),(1268,'DOT Approved','Describes If Department of Transportation Approved'),(1269,'Filament Quantity','Describes Quantity'),(1270,'Beam Type','Describes Type'),(1271,'Street Legal','Describes If Street Legal'),(1272,'Bulb Color','Describes the Color of the Bulb Material'),(1284,'Bulb Base Type','Describes The Type Of Bulb Base. i.e. Wedge etc...'),(1318,'Size','Describes Size'),(1671,'Nylon Mesh Overwrap','Describes If Has Nylon Mesh Overwrap'),(1672,'Washable','Describes If Washable'),(1681,'Handle Included','Describes If Handle Is Included'),(1822,'Bulb Type','Describes the Bulb Shape Code Type, Category, or Trade Number i.e. S8, W16W. H1 etc...'),(1917,'Washer Included','Describes If Washer Is Included'),(2393,'Sleeve Length','Describes Measurement'),(2705,'Multi Surface','Describes If Has Multi Surfaces'),(2786,'Average Rated Life','Describes Average Rated Life'),(3390,'Grade Type','Describes Type Of Grade'),(3596,'Backing Material','Describes Material'),(3858,'Electrical Terminal Type','Describes Type Of Terminal'),(4543,'Brake Lubricant Included','Describes If Brake Lubricant Is Included'),(4748,'Pocket Quantity','Describes Quantity Of Pockets'),(5217,'Logo Location','Describes Where Logo Is Located'),(5950,'Bulb Material','Describes the Material of the Bulb'),(6648,'Skirt Length','Describes The Length Of The Piston Skirt'),(7321,'Pad Quantity','Describes Quantity'),(7673,'Backing Plate Color','Describes Color'),(8363,'Brightness','Describes The Brightness'),(8701,'Pad Shim Material','Describes Material'),(9059,'Abutment Clips Included','Describes If Abutment Clips Are Included'),(9066,'Pad Wear Sensor Type','Describes What Type of Pad Wear Sensor Is Included'),(9076,'Chamfered Edges','Describes if the product has chamfered edges'),(9078,'Light Color Temperature','Describes Light Color Temperature Measurement'),(9079,'Secondary Brightness','Describes The Brightness'),(9080,'Secondary Average Rated Life','Describes the Average Life-Span of the Product'),(9081,'Secondary Filament Type','Filament Type Number'),(9082,'Secondary Amperage Rating','Describes Amperage Measurement'),(9083,'Secondary Wattage','Describes Wattage Measurement'),(9084,'Secondary Voltage','Describes Voltage Measurement'),(9085,'Filament Type','Filament Type Number'),(9086,'Bulb Technology','Describes the Type of Bulb Technology. i.e. Halogen, LED, etc...'),(9087,'Bulb Finish','Describes the Finish of the Bulb'),(9286,'Prepared For Pad Wear Sensor','Describes If Product Is Prepared For A Pad Wear Sensor Or Not'),(9294,'Gender Category','Describes The Gender Category Of Apparel'),(9383,'Ground Electrode Tip Material','Describes The Material Of The Ground Electrode Tip'),(9407,'ECE-R90 Certified','Describes If Product Is ECE-R90 Certified'),(9421,'Pad Shim Color','Describes Color of the Pad Shim'),(9422,'Adhesive Backed Pad Shim','Describes if adhesive layer is used on the back of the pad shim.'),(9423,'Friction Surface Scorched','Describes if the Friction Surface has been Scorched.'),(9433,'Outer Pad Height','Describes The Height Of The Outer Portion Of The Pad'),(9434,'Inner Pad Height','Describes The Height Of The Inner Portion Of The Pad'),(9435,'Outer Pad Width','Describes The Width Of The Outer Portion Of The Pad'),(9436,'Inner Pad Width','Describes The Width Of The Inner Portion Of The Pad'),(9459,'Skirt','Describes If Product Has A Skirt As Part Of It\'s Construction.'),(9478,'Outer Pad Overall Thickness','Describes The Overall Thickness Of The Outer Pad.'),(9479,'Inner Pad Overall Thickness','Describes The Overall Thickness Of The Inner Pad.'),(9506,'Center Electrode Insulator Tip Projection','Describes The Projection Measurement Of The Center Electrode Insulator Tip.'),(9507,'Hex Type','Describes The Type Of Hex.'),(9608,'Center Electrode Design','Describes The Design Of The Center Electrode.'),(9717,'Color Rendering Index (CRI)','Describes The Color Rendering Index (CRI) Of The Product.'),(9745,'Washer Type','Describes The Type Of Washer.'),(9746,'Indexed','Describes If The Product Is Indexed.'),(9748,'Core Nose Length','This is the length of the ceramic section of the insulator inside an spark plug\'s shell.'),(9793,'Indicated Mean Effective Pressure (IMEP)','The Average Pressure Acting On A Piston During It\'s Cycles Different Sections From Inside It\'s Cylinder.'),(9805,'Center Electrode Projection','Describes The Projection Of The Center Electrode.'),(9995,'Primary Brightness','Describes the low/first filament in a bulb.'),(10147,'Flavor','Describes The Flavor Of The Candy.'),(10148,'Candy Type','Describes The Type Of Candy.');
/*!40000 ALTER TABLE `PartAttributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PartTypeStyle`
--

DROP TABLE IF EXISTS `PartTypeStyle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PartTypeStyle` (
  `StyleID` int(11) DEFAULT NULL,
  `PartTerminologyID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PartTypeStyle`
--

LOCK TABLES `PartTypeStyle` WRITE;
/*!40000 ALTER TABLE `PartTypeStyle` DISABLE KEYS */;
/*!40000 ALTER TABLE `PartTypeStyle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Style`
--

DROP TABLE IF EXISTS `Style`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Style` (
  `StyleID` int(11) DEFAULT NULL,
  `StyleName` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Style`
--

LOCK TABLES `Style` WRITE;
/*!40000 ALTER TABLE `Style` DISABLE KEYS */;
/*!40000 ALTER TABLE `Style` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ValidValueAssignment`
--

DROP TABLE IF EXISTS `ValidValueAssignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ValidValueAssignment` (
  `ValidValueAssignmentID` int(11) NOT NULL,
  `PAPTID` int(11) NOT NULL,
  `ValidValueID` int(11) NOT NULL,
  PRIMARY KEY (`ValidValueAssignmentID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ValidValueAssignment`
--

LOCK TABLES `ValidValueAssignment` WRITE;
/*!40000 ALTER TABLE `ValidValueAssignment` DISABLE KEYS */;
INSERT INTO `ValidValueAssignment` VALUES (865,126122,966),(866,126122,881),(7254,136527,996),(7255,136527,276),(17854,154735,1341),(17855,154735,812),(20017,22002,1341),(20018,22002,812),(20067,22059,1341),(20068,22059,812),(20069,22060,1341),(20070,22060,812),(22032,24938,1341),(22033,24938,812),(23474,27746,1341),(23475,27746,812),(23476,27749,1341),(23477,27749,812),(23480,27751,1341),(23481,27751,812),(23482,27755,1341),(23483,27755,812),(60401,76668,1341),(60402,76668,812),(101285,156238,1341),(101286,156238,812),(101308,156257,397),(101309,156257,1167),(101310,156257,972),(101311,156257,824),(101587,156460,1341),(101588,156460,812),(101589,156461,1341),(101590,156461,812),(101599,156473,464),(101600,156473,772),(101601,156474,1341),(101602,156474,812),(101603,156486,6),(101604,156486,23),(101605,156488,599),(101606,156488,614),(101607,156488,644),(101608,156488,712),(101609,156490,339),(101610,156490,545),(101611,156490,844),(101612,156491,579),(101613,156491,890),(101614,156503,6),(101615,156503,23),(101616,156509,599),(101617,156509,614),(101618,156509,644),(101619,156509,712),(101620,156511,339),(101621,156511,545),(101622,156511,844),(101623,156512,579),(101624,156512,890),(102886,157654,515),(102887,157654,1191),(103117,156473,465),(103122,156488,525),(103123,156509,525),(105892,136527,665),(105895,158983,1341),(105896,158983,812),(106549,136527,785),(110498,160596,781),(110499,160596,1057),(110500,160596,331),(110501,160596,849),(110679,160629,807),(110680,160629,2),(110681,160629,67),(110682,160629,126),(110683,160629,155),(110684,160629,11),(110685,160629,61),(110686,160629,87),(110687,160629,109),(110688,160629,1343),(110689,160629,1349),(110690,160629,1347),(110691,160629,1345),(110692,160629,1342),(110693,160629,485),(110694,160629,1101),(110695,160629,773),(110696,160629,705),(110697,160629,706),(110698,160629,483),(110699,160629,484),(110700,160629,62),(110701,160629,63),(110702,160629,88),(110703,160629,89),(110704,160629,110),(110705,160629,111),(110728,160633,776),(110729,160633,1331),(110730,160633,282),(110731,160633,578),(110732,160633,1217),(110733,160633,1218),(110734,160633,653),(110735,160633,654),(110736,160629,64),(123235,165998,542),(123236,165998,957),(123237,165998,543),(152188,169222,802),(152189,169222,1177),(158328,164501,381),(158329,158751,808),(158330,158751,1358),(158331,158751,1359),(158332,158751,1360),(158333,158751,1361),(158334,158751,1362),(158335,158751,1363),(158336,24633,381),(158337,24633,808),(158338,24633,1360),(158339,172419,808),(158340,172419,1360),(158490,160596,1378),(158571,172687,1341),(158572,172687,812),(158575,172689,1341),(158576,172689,812),(162027,183232,1341),(162028,183232,812),(162029,183233,1341),(162030,183233,812),(162387,184693,23),(162388,184693,90),(162389,184693,1418),(162390,184693,1419),(162391,184693,1420),(162964,185219,1341),(162965,185219,812),(163397,185494,612),(163398,185494,1625),(163787,185987,1710),(163788,185987,1142),(166205,188503,1341),(166206,188503,812),(166207,188504,515),(166208,188504,2280),(166209,188505,1341),(166210,188505,812),(166851,188987,331),(166934,160596,2279),(166944,189274,2300),(166945,189274,2301),(166946,189274,2302),(166947,189274,2303),(166948,189274,2304),(166949,189274,2305),(166950,189274,2306),(167041,172419,2307),(168847,160596,2494),(173406,193704,1341),(173407,193704,812),(173929,160629,2842);
/*!40000 ALTER TABLE `ValidValueAssignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ValidValues`
--

DROP TABLE IF EXISTS `ValidValues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ValidValues` (
  `ValidValueID` int(11) NOT NULL,
  `ValidValue` varchar(100) NOT NULL,
  PRIMARY KEY (`ValidValueID`),
  UNIQUE KEY `ValidValue` (`ValidValue`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ValidValues`
--

LOCK TABLES `ValidValues` WRITE;
/*!40000 ALTER TABLE `ValidValues` DISABLE KEYS */;
INSERT INTO `ValidValues` VALUES (2,'0-3 Months'),(6,'1'),(1420,'10'),(11,'12-18 Months'),(2842,'18-24 Months'),(23,'2'),(61,'2T'),(62,'2XL'),(63,'2XL Tall'),(64,'2XS'),(67,'3-6 Months'),(87,'3T'),(88,'3XL'),(89,'3XL Tall'),(90,'4'),(109,'4T'),(110,'4XL'),(111,'4XL Tall'),(1418,'6'),(126,'6-9 Months'),(1419,'8'),(155,'9-12 Months'),(1625,'Bi-Hex'),(276,'Bonded'),(282,'Boys'),(1378,'Carbon Fiber Ceramic'),(331,'Ceramic'),(339,'Clear'),(381,'Copper'),(2280,'Crush'),(397,'Cup'),(464,'Electronic'),(465,'Electronic and Mechanical'),(483,'Extra Large'),(484,'Extra Large Tall'),(485,'Extra Small'),(2300,'Extra-Long Projection'),(2301,'Extra-Long Special'),(1710,'Fine Wire'),(515,'Flat'),(525,'Fluorescent'),(542,'Front'),(543,'Front Rear'),(545,'Frosted'),(578,'Girls'),(579,'Glass'),(1358,'Gold-Palladium'),(599,'Halogen'),(612,'Hex'),(614,'HID'),(2279,'Hybrid'),(644,'Incandescent'),(653,'Infant Boys'),(654,'Infant Girls'),(665,'Integrally Molded'),(1359,'Iridium'),(2307,'Iridium-Platinum'),(705,'Large'),(706,'Large Tall'),(712,'LED'),(2302,'Long Projection'),(2494,'Low-Metallic'),(772,'Mechanical'),(773,'Medium'),(776,'Mens'),(781,'Metallic'),(2303,'Mid Projection'),(785,'Mixed'),(802,'Natural'),(807,'Newborn'),(808,'Nickel'),(812,'No'),(2304,'Non-Projected'),(824,'Non-Removable Nut'),(844,'Opaque'),(849,'Organic'),(881,'Performance'),(890,'Plastic'),(1360,'Platinum'),(957,'Rear'),(966,'Regular'),(972,'Removable Nut'),(996,'Riveted'),(1361,'Ruthenium'),(1057,'Semi-metallic'),(2305,'Short Projection'),(1362,'Silver'),(1101,'Small'),(1142,'Standard'),(1167,'Stud'),(2306,'Surface Gap'),(1177,'Synthetic'),(1191,'Tapered'),(1217,'Toddler Boys'),(1218,'Toddler Girls'),(1363,'Tungsten'),(1331,'Womens'),(1341,'Yes'),(1342,'Youth Extra Large'),(1343,'Youth Extra Small'),(1345,'Youth Large'),(1347,'Youth Medium'),(1349,'Youth Small');
/*!40000 ALTER TABLE `ValidValues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Version`
--

DROP TABLE IF EXISTS `Version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Version` (
  `PAdbVersion` varchar(10) DEFAULT NULL,
  `PAdbPublication` date DEFAULT NULL,
  `PCdbPublication` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Version`
--

LOCK TABLES `Version` WRITE;
/*!40000 ALTER TABLE `Version` DISABLE KEYS */;
INSERT INTO `Version` VALUES ('4.0','2023-05-18','2023-05-18');
/*!40000 ALTER TABLE `Version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-15 17:52:52
