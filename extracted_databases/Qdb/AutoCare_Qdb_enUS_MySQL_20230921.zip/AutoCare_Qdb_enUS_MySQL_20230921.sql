-- MySQL dump 10.13  Distrib 5.7.16, for Win64 (x86_64)
--
-- Host: localhost    Database: EnhancedStandard_QDB_Exported_PRD_20230921
-- ------------------------------------------------------
-- Server version	5.7.28-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ChangeAttributeStates`
--

DROP TABLE IF EXISTS `ChangeAttributeStates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ChangeAttributeStates` (
  `ChangeAttributeStateID` int(11) NOT NULL,
  `ChangeAttributeState` varchar(255) NOT NULL,
  PRIMARY KEY (`ChangeAttributeStateID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChangeAttributeStates`
--

LOCK TABLES `ChangeAttributeStates` WRITE;
/*!40000 ALTER TABLE `ChangeAttributeStates` DISABLE KEYS */;
INSERT INTO `ChangeAttributeStates` VALUES (1,'Add'),(2,'Delete'),(3,'Modify');
/*!40000 ALTER TABLE `ChangeAttributeStates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChangeDetails`
--

DROP TABLE IF EXISTS `ChangeDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ChangeDetails` (
  `ChangeDetailID` int(11) NOT NULL AUTO_INCREMENT,
  `ChangeID` int(11) NOT NULL,
  `ChangeAttributeStateID` int(11) NOT NULL,
  `TableNameID` int(11) NOT NULL,
  `PrimaryKeyColumnName` varchar(255) DEFAULT NULL,
  `PrimaryKeyBefore` int(11) DEFAULT NULL,
  `PrimaryKeyAfter` int(11) DEFAULT NULL,
  `ColumnName` varchar(255) DEFAULT NULL,
  `ColumnValueBefore` varchar(1000) DEFAULT NULL,
  `ColumnValueAfter` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`ChangeDetailID`),
  KEY `IDX_ChangeDetails_Changes_ChangeID` (`ChangeID`),
  KEY `IDX_ChangeDetails_ChangeAttributeStates_ChangeAttributeStateID` (`ChangeAttributeStateID`),
  KEY `IDX_ChangeDetails_ChangeTableNames_TableNameID` (`TableNameID`),
  CONSTRAINT `FK_ChangeAttributeStates_ChangeDetails` FOREIGN KEY (`ChangeAttributeStateID`) REFERENCES `changeattributestates` (`ChangeAttributeStateID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ChangeTableNames_ChangeDetails` FOREIGN KEY (`TableNameID`) REFERENCES `changetablenames` (`TableNameID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_Changes_ChangeDetails` FOREIGN KEY (`ChangeID`) REFERENCES `changes` (`ChangeID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=183406 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChangeDetails`
--

LOCK TABLES `ChangeDetails` WRITE;
/*!40000 ALTER TABLE `ChangeDetails` DISABLE KEYS */;
INSERT INTO `ChangeDetails` VALUES (221,61,1,1,'QualifierID',NULL,23925,'QualifierText',NULL,'After <p1 type=\"date\"/>'),(222,61,1,1,'QualifierID',NULL,23925,'ExampleText',NULL,'After 01/01/2001'),(223,61,1,1,'QualifierID',NULL,23925,'QualifierTypeId',NULL,'1'),(224,61,1,1,'QualifierID',NULL,23925,'QualifierID',NULL,'23925'),(816,237,3,1,'QualifierID',22775,22775,'QualifierTypeId','3','9'),(855,249,3,1,'QualifierID',23487,23487,'QualifierText','Engine Family Number <p1 type=\"idlist\"/>','Engine Family Number (EFN) <p1 type=\"idlist\"/>'),(856,249,3,1,'QualifierID',23487,23487,'ExampleText','Engine Family Number VHN2.2VJGKEK','Engine Family Number (EFN) TGM5.7CPGAEA'),(1063,313,1,1,'QualifierID',NULL,24123,'QualifierText',NULL,'with Vertical Aim Control'),(1064,313,1,1,'QualifierID',NULL,24123,'ExampleText',NULL,'with Vertical Aim Control'),(1065,313,1,1,'QualifierID',NULL,24123,'QualifierTypeId',NULL,'1'),(1066,313,1,1,'QualifierID',NULL,24123,'QualifierID',NULL,'24123'),(1075,316,1,1,'QualifierID',NULL,24120,'QualifierText',NULL,'without Vertical Aim Control'),(1076,316,1,1,'QualifierID',NULL,24120,'ExampleText',NULL,'without Vertical Aim Control'),(1077,316,1,1,'QualifierID',NULL,24120,'QualifierTypeId',NULL,'1'),(1078,316,1,1,'QualifierID',NULL,24120,'QualifierID',NULL,'24120'),(3681,4956,1,1,'QualifierID',NULL,24422,'QualifierText',NULL,'Must Match OE Number(s) <p1 type=\"idlist\"/> On Back of Cluster'),(3682,4956,1,1,'QualifierID',NULL,24422,'ExampleText',NULL,'Must Match OE Number(s) <p1 type=\"idlist\"/> On Back of Cluster'),(3683,4956,1,1,'QualifierID',NULL,24422,'QualifierTypeId',NULL,'2'),(3684,4956,1,1,'QualifierID',NULL,24422,'QualifierID',NULL,'24422'),(5505,5531,1,1,'QualifierId',NULL,24697,'QualifierId',NULL,'24697'),(5506,5531,1,1,'QualifierId',NULL,24697,'QualifierText',NULL,'If vehicle has <p1 type=\"size\"/> wide leaf springs, use bracket kit <p2 type=\"part\"/>'),(5507,5531,1,1,'QualifierId',NULL,24697,'ExampleText',NULL,'If vehicle has 2.5 in wide leaf springs, use bracket kit RS5558'),(5508,5531,1,1,'QualifierId',NULL,24697,'QualifierTypeId',NULL,'3'),(7667,6159,1,1,'QualifierId',NULL,25171,'QualifierId',NULL,'25171'),(7668,6159,1,1,'QualifierId',NULL,25171,'QualifierText',NULL,'with Sport Suspension'),(7669,6159,1,1,'QualifierId',NULL,25171,'ExampleText',NULL,'with Sport Suspension'),(7670,6159,1,1,'QualifierId',NULL,25171,'QualifierTypeId',NULL,'1'),(7671,6159,1,4,'QualifierGroupId',NULL,2477,'GroupNumberId',NULL,'1239'),(7672,6159,1,4,'QualifierGroupId',NULL,2477,'QualifierId',NULL,'25171'),(7673,6159,1,4,'QualifierGroupId',NULL,2477,'QualifierGroupId',NULL,'2477'),(7674,6160,1,1,'QualifierId',NULL,25172,'QualifierId',NULL,'25172'),(7675,6160,1,1,'QualifierId',NULL,25172,'QualifierText',NULL,'without Sport Suspension'),(7676,6160,1,1,'QualifierId',NULL,25172,'ExampleText',NULL,'without Sport Suspension'),(7677,6160,1,1,'QualifierId',NULL,25172,'QualifierTypeId',NULL,'1'),(7678,6160,1,4,'QualifierGroupId',NULL,2478,'GroupNumberId',NULL,'1239'),(7679,6160,1,4,'QualifierGroupId',NULL,2478,'QualifierId',NULL,'25172'),(7680,6160,1,4,'QualifierGroupId',NULL,2478,'QualifierGroupId',NULL,'2478'),(94911,28848,3,1,'QualifierId',24422,24422,'QualifierText','Must Match OE Number(s) <p1 type=\"idlist\"/> On Back of Cluster','Must match OE Number # <p1 type=\"idlist\"/> on back of Cluster'),(94912,28848,3,1,'QualifierId',24422,24422,'ExampleText','Must Match OE Number(s) <p1 type=\"idlist\"/> On Back of Cluster','Must match OE Number # <p1 type=\"idlist\"/> on back of Cluster'),(101465,30833,1,1,'QualifierId',NULL,26216,'QualifierId',NULL,'26216'),(101466,30833,1,1,'QualifierId',NULL,26216,'QualifierText',NULL,'with <p1 type=\"weight\"/> - <p2 type=\"weight\"/> <p3 type=\"name\"/> Air Suspension'),(101467,30833,1,1,'QualifierId',NULL,26216,'ExampleText',NULL,'with 38,000 lb - 40,000 lb Peterbilt Air Suspension'),(101468,30833,1,1,'QualifierId',NULL,26216,'QualifierTypeId',NULL,'1'),(101489,30839,1,1,'QualifierId',NULL,26222,'QualifierId',NULL,'26222'),(101490,30839,1,1,'QualifierId',NULL,26222,'QualifierText',NULL,'For <p1 type=\"type\"/> Biodiesel Engines Only'),(101491,30839,1,1,'QualifierId',NULL,26222,'ExampleText',NULL,'For B5 Biodiesel Engines Only'),(101492,30839,1,1,'QualifierId',NULL,26222,'QualifierTypeId',NULL,'1'),(101794,30930,3,1,'QualifierId',22940,22940,'QualifierText','<p1 type=\"size\"/> - < p2 type=\"num\"/> Spline','<p1 type=\"size\"/> - <p2 type=\"num\"/> Spline'),(101795,30930,3,1,'QualifierId',22940,22940,'ExampleText','','1.58 in - 36 Spline'),(105832,32066,1,1,'QualifierId',NULL,27136,'QualifierId',NULL,'27136'),(105833,32066,1,1,'QualifierId',NULL,27136,'QualifierText',NULL,'with <p1 type=\"size\"/> and <p2 type=\"size\"/> Cabs with <p3 type=\"name\"/> Model <p4 type=\"idlist\"/>'),(105834,32066,1,1,'QualifierId',NULL,27136,'ExampleText',NULL,'with 89 in and 110 in Cabs with Link Cabmate Model NAV9876'),(105835,32066,1,1,'QualifierId',NULL,27136,'QualifierTypeId',NULL,'1'),(109984,33771,1,1,'QualifierId',NULL,27230,'QualifierId',NULL,'27230'),(109985,33771,1,1,'QualifierId',NULL,27230,'QualifierText',NULL,'Valve cover gasket (/s) included'),(109986,33771,1,1,'QualifierId',NULL,27230,'ExampleText',NULL,'Valve cover gasket (/s) included'),(109987,33771,1,1,'QualifierId',NULL,27230,'QualifierTypeId',NULL,'5'),(110000,33776,3,1,'QualifierId',27230,27230,'QualifierText','Valve cover gasket (/s) included','Valve Cover Gasket(s) Included'),(110001,33776,3,1,'QualifierId',27230,27230,'ExampleText','Valve cover gasket (/s) included','Valve Cover Gasket(s) Included'),(111001,34040,1,1,'QualifierId',NULL,27470,'QualifierId',NULL,'27470'),(111002,34040,1,1,'QualifierId',NULL,27470,'QualifierText',NULL,'Torque To Yield Bolts Must Be Replaced'),(111003,34040,1,1,'QualifierId',NULL,27470,'ExampleText',NULL,'Torque To Yield Bolts Must Be Replaced'),(111004,34040,1,1,'QualifierId',NULL,27470,'QualifierTypeId',NULL,'6'),(183402,52227,1,1,'QualifierId',NULL,27866,'QualifierId',NULL,'27866'),(183403,52227,1,1,'QualifierId',NULL,27866,'QualifierText',NULL,'Requires Removal of Factory Upper Arm Frame Droop Stops'),(183404,52227,1,1,'QualifierId',NULL,27866,'ExampleText',NULL,'Requires Removal of Factory Upper Arm Frame Droop Stops'),(183405,52227,1,1,'QualifierId',NULL,27866,'QualifierTypeId',NULL,'4');
/*!40000 ALTER TABLE `ChangeDetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChangeReasons`
--

DROP TABLE IF EXISTS `ChangeReasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ChangeReasons` (
  `ChangeReasonID` int(11) NOT NULL,
  `ChangeReason` varchar(255) NOT NULL,
  PRIMARY KEY (`ChangeReasonID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChangeReasons`
--

LOCK TABLES `ChangeReasons` WRITE;
/*!40000 ALTER TABLE `ChangeReasons` DISABLE KEYS */;
INSERT INTO `ChangeReasons` VALUES (1,'New Research'),(2,'Batch Data Import'),(3,'Record Merge'),(4,'Record Split'),(5,'Attribute Value Invalid'),(6,'Attribute Value Update');
/*!40000 ALTER TABLE `ChangeReasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChangeTableNames`
--

DROP TABLE IF EXISTS `ChangeTableNames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ChangeTableNames` (
  `TableNameID` int(11) NOT NULL,
  `TableName` varchar(255) NOT NULL,
  `TableDescription` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`TableNameID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChangeTableNames`
--

LOCK TABLES `ChangeTableNames` WRITE;
/*!40000 ALTER TABLE `ChangeTableNames` DISABLE KEYS */;
INSERT INTO `ChangeTableNames` VALUES (1,'Qualifier',NULL),(2,'QualifierType',NULL),(3,'GroupNumber',NULL),(4,'QualifierGroup',NULL);
/*!40000 ALTER TABLE `ChangeTableNames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Changes`
--

DROP TABLE IF EXISTS `Changes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Changes` (
  `ChangeID` int(11) NOT NULL AUTO_INCREMENT,
  `RequestID` int(11) NOT NULL,
  `ChangeReasonID` int(11) NOT NULL,
  `RevDate` datetime DEFAULT NULL,
  PRIMARY KEY (`ChangeID`),
  KEY `IDX_Changes_ChangeReason_ChangeReasonID` (`ChangeReasonID`),
  CONSTRAINT `FK_ChangeReason_Changes` FOREIGN KEY (`ChangeReasonID`) REFERENCES `changereasons` (`ChangeReasonID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=52228 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Changes`
--

LOCK TABLES `Changes` WRITE;
/*!40000 ALTER TABLE `Changes` DISABLE KEYS */;
INSERT INTO `Changes` VALUES (61,43399,1,'2017-09-29 00:00:00'),(237,113333,6,'2018-05-25 00:00:00'),(249,113642,6,'2018-05-25 00:00:00'),(313,344929,1,'2019-03-29 00:00:00'),(316,344932,1,'2019-03-29 00:00:00'),(4956,737833,1,'2020-01-31 00:00:00'),(5531,819341,1,'2020-07-31 00:00:00'),(6159,932249,1,'2020-11-20 00:00:00'),(6160,932248,1,'2020-11-20 00:00:00'),(28848,1140888,6,'2021-04-30 00:00:00'),(30833,1288803,1,'2021-09-24 00:00:00'),(30839,1283205,1,'2021-09-24 00:00:00'),(30930,1292790,6,'2021-10-29 00:00:00'),(32066,1642434,1,'2022-04-29 00:00:00'),(33771,1934097,1,'2022-09-30 00:00:00'),(33776,1939482,6,'2022-09-30 00:00:00'),(34040,2217000,1,'2023-01-12 00:00:00'),(52227,2450097,1,'2023-06-29 00:00:00');
/*!40000 ALTER TABLE `Changes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GroupNumber`
--

DROP TABLE IF EXISTS `GroupNumber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GroupNumber` (
  `GroupNumberID` int(11) NOT NULL,
  `GroupDescription` varchar(100) NOT NULL,
  PRIMARY KEY (`GroupNumberID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GroupNumber`
--

LOCK TABLES `GroupNumber` WRITE;
/*!40000 ALTER TABLE `GroupNumber` DISABLE KEYS */;
INSERT INTO `GroupNumber` VALUES (1237,'with/without Vertical Aim Control'),(1239,'with/without Sport Suspension');
/*!40000 ALTER TABLE `GroupNumber` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Language`
--

DROP TABLE IF EXISTS `Language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Language` (
  `LanguageID` int(11) DEFAULT NULL,
  `LanguageName` varchar(50) DEFAULT NULL,
  `DialectName` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Language`
--

LOCK TABLES `Language` WRITE;
/*!40000 ALTER TABLE `Language` DISABLE KEYS */;
/*!40000 ALTER TABLE `Language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QdbChanges`
--

DROP TABLE IF EXISTS `QdbChanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QdbChanges` (
  `VersionDate` datetime DEFAULT NULL,
  `QualifierID` int(11) DEFAULT NULL,
  `QualifierText` varchar(500) DEFAULT NULL,
  `Action` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QdbChanges`
--

LOCK TABLES `QdbChanges` WRITE;
/*!40000 ALTER TABLE `QdbChanges` DISABLE KEYS */;
INSERT INTO `QdbChanges` VALUES ('2018-05-25 00:00:00',22775,'CARB Executive Order <p1 type=\"idlist\"/>','M'),('2018-05-25 00:00:00',23487,'Engine Family Number (EFN) <p1 type=\"idlist\"/>','M'),('2022-09-30 00:00:00',27230,'Valve cover gasket (/s) included','A'),('2022-09-30 00:00:00',27230,'Valve cover gasket (/s) included','M'),('2023-01-12 00:00:00',27470,'Torque To Yield Bolts Must Be Replaced','A'),('2023-06-29 00:00:00',27866,'Requires Removal of Factory Upper Arm Frame Droop Stops','A'),('2022-04-29 00:00:00',27136,'with <p1 type=\"size\"/> and <p2 type=\"size\"/> Cabs with <p3 type=\"name\"/> Model <p4 type=\"idlist\"/>','A'),('2021-05-28 00:00:00',24422,'Debe Coincidir con Número(s) de Equipo Original <p1 type=\"idlist\"/> en Parte Posterior del Grupo de Instrumentos','M'),('2019-03-29 00:00:00',24120,'without Vertical Aim Control','A'),('2019-03-29 00:00:00',24123,'with Vertical Aim Control','A'),('2021-10-29 00:00:00',22940,'Estría de <p1 type=\"size\"/> - <p2 type=\"num\"/>','M'),('2020-12-18 00:00:00',25171,'with Sport Suspension','A'),('2020-12-18 00:00:00',25172,'without Sport Suspension','A'),('2020-01-31 00:00:00',24422,'Must Match OE Number(s) <p1 type=\"idlist\"/> On Back of Cluster','A'),('2019-12-20 00:00:00',24120,'without Vertical Aim Control','M'),('2019-12-20 00:00:00',24123,'with Vertical Aim Control','M'),('2017-09-29 00:00:00',23925,'After <p1 type=\"date\"/>','A'),('2021-09-24 00:00:00',26216,'with <p1 type=\"weight\"/> - <p2 type=\"weight\"/> <p3 type=\"name\"/> Air Suspension','A'),('2021-09-24 00:00:00',26222,'For <p1 type=\"type\"/> Biodiesel Engines Only','A'),('2020-07-31 00:00:00',24697,'If vehicle has <p1 type=\"size\"/> wide leaf springs, use bracket kit <p2 type=\"part\"/>','A');
/*!40000 ALTER TABLE `QdbChanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Qualifier`
--

DROP TABLE IF EXISTS `Qualifier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Qualifier` (
  `QualifierID` int(11) NOT NULL,
  `QualifierText` varchar(500) DEFAULT NULL,
  `ExampleText` varchar(500) DEFAULT NULL,
  `QualifierTypeID` int(11) NOT NULL,
  `NewQualifierID` int(11) DEFAULT NULL,
  `WhenModified` datetime NOT NULL,
  PRIMARY KEY (`QualifierID`),
  KEY `FK_Qualifier_QualifierType_QualifierTypeID` (`QualifierTypeID`),
  CONSTRAINT `FK_Qualifier_QualifierType_QualifierTypeID` FOREIGN KEY (`QualifierTypeID`) REFERENCES `QualifierType` (`QualifierTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Qualifier`
--

LOCK TABLES `Qualifier` WRITE;
/*!40000 ALTER TABLE `Qualifier` DISABLE KEYS */;
INSERT INTO `Qualifier` VALUES (6537,'Mounting Ears at <p1 type=\"clock\"/> O\'Clock','Mounting Ears at 3 O\'Clock',1,NULL,'2010-01-20 14:31:00'),(22775,'CARB Executive Order <p1 type=\"idlist\"/>','CARB Executive Order D-160-61',9,NULL,'2018-05-21 19:44:00'),(22940,'<p1 type=\"size\"/> - <p2 type=\"num\"/> Spline','1.58 in - 36 Spline',1,NULL,'2021-10-08 12:31:00'),(23487,'Engine Family Number (EFN) <p1 type=\"idlist\"/>','Engine Family Number (EFN) TGM5.7CPGAEA',1,NULL,'2018-05-21 19:42:00'),(23683,'with <p1 type=\"size\"/> - <p2 type=\"size\"/> Lift Kit (Dual shock Forward of Axle)','with 2\" - 3\" Lift Kit (Dual shock Forward of Axle',1,NULL,'2015-09-29 07:48:00'),(23684,'with <p1 type=\"size\"/> Lift Kit (Dual shock Forward of Axle)','with 3\" Lift Kit (Dual shock Forward of Axle)',1,NULL,'2015-09-29 07:48:00'),(23925,'After <p1 type=\"date\"/>','After 01/01/2001',1,NULL,'2017-09-18 18:50:00'),(24120,'without Vertical Aim Control','without Vertical Aim Control',1,NULL,'2019-12-10 15:34:00'),(24123,'with Vertical Aim Control','with Vertical Aim Control',1,NULL,'2019-12-10 15:26:00'),(24422,'Must match OE Number # <p1 type=\"idlist\"/> on back of Cluster','Must match OE Number # <p1 type=\"idlist\"/> on back of Cluster',2,NULL,'2021-04-30 17:09:00'),(24697,'If vehicle has <p1 type=\"size\"/> wide leaf springs, use bracket kit <p2 type=\"part\"/>','If vehicle has 2.5 in wide leaf springs, use bracket kit RS5558',3,NULL,'2020-07-27 15:55:00'),(25171,'with Sport Suspension','with Sport Suspension',1,NULL,'2020-12-11 21:10:00'),(25172,'without Sport Suspension','without Sport Suspension',1,NULL,'2020-12-11 21:10:00'),(26216,'with <p1 type=\"weight\"/> - <p2 type=\"weight\"/> <p3 type=\"name\"/> Air Suspension','with 38,000 lb - 40,000 lb Peterbilt Air Suspension',1,NULL,'2021-09-17 18:31:00'),(26222,'For <p1 type=\"type\"/> Biodiesel Engines Only','For B5 Biodiesel Engines Only',1,NULL,'2021-09-17 18:34:00'),(27136,'with <p1 type=\"size\"/> and <p2 type=\"size\"/> Cabs with <p3 type=\"name\"/> Model <p4 type=\"idlist\"/>','with 89 in and 110 in Cabs with Link Cabmate Model NAV9876',1,NULL,'2022-04-14 17:03:00'),(27230,'Valve Cover Gasket(s) Included','Valve Cover Gasket(s) Included',5,NULL,'2022-09-15 22:40:00'),(27470,'Torque To Yield Bolts Must Be Replaced','Torque To Yield Bolts Must Be Replaced',6,NULL,'2023-01-06 16:21:00'),(27866,'Requires Removal of Factory Upper Arm Frame Droop Stops','Requires Removal of Factory Upper Arm Frame Droop Stops',4,NULL,'2023-06-27 03:46:00');
/*!40000 ALTER TABLE `Qualifier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QualifierGroup`
--

DROP TABLE IF EXISTS `QualifierGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QualifierGroup` (
  `QualifierGroupID` int(11) NOT NULL,
  `GroupNumberID` int(11) NOT NULL,
  `QualifierID` int(11) NOT NULL,
  PRIMARY KEY (`QualifierGroupID`),
  KEY `FK_QualifierGroup_Qualifier_QualifierId` (`QualifierID`),
  KEY `FK_QualifierGroup_QualifierGroupType_GroupId` (`GroupNumberID`),
  CONSTRAINT `FK_QualifierGroup_QualifierGroupType_GroupId` FOREIGN KEY (`GroupNumberID`) REFERENCES `GroupNumber` (`GroupNumberID`),
  CONSTRAINT `FK_QualifierGroup_Qualifier_QualifierId` FOREIGN KEY (`QualifierID`) REFERENCES `Qualifier` (`QualifierID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QualifierGroup`
--

LOCK TABLES `QualifierGroup` WRITE;
/*!40000 ALTER TABLE `QualifierGroup` DISABLE KEYS */;
INSERT INTO `QualifierGroup` VALUES (2246,1237,24123),(2379,1237,24120),(2477,1239,25171),(2478,1239,25172);
/*!40000 ALTER TABLE `QualifierGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QualifierTranslation`
--

DROP TABLE IF EXISTS `QualifierTranslation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QualifierTranslation` (
  `QualifierTranslationID` int(11) NOT NULL,
  `QualifierID` int(11) NOT NULL,
  `LanguageID` int(11) NOT NULL,
  `TranslationText` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QualifierTranslation`
--

LOCK TABLES `QualifierTranslation` WRITE;
/*!40000 ALTER TABLE `QualifierTranslation` DISABLE KEYS */;
/*!40000 ALTER TABLE `QualifierTranslation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QualifierType`
--

DROP TABLE IF EXISTS `QualifierType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `QualifierType` (
  `QualifierTypeID` int(11) NOT NULL,
  `QualifierType` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`QualifierTypeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QualifierType`
--

LOCK TABLES `QualifierType` WRITE;
/*!40000 ALTER TABLE `QualifierType` DISABLE KEYS */;
INSERT INTO `QualifierType` VALUES (1,'Fitment'),(2,'OE Only'),(3,'Informational'),(4,'Installation'),(5,'Product'),(6,'Caution'),(9,'Emission');
/*!40000 ALTER TABLE `QualifierType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Version`
--

DROP TABLE IF EXISTS `Version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Version` (
  `VersionDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Version`
--

LOCK TABLES `Version` WRITE;
/*!40000 ALTER TABLE `Version` DISABLE KEYS */;
INSERT INTO `Version` VALUES ('2023-09-21 00:00:00');
/*!40000 ALTER TABLE `Version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-19 16:41:11
